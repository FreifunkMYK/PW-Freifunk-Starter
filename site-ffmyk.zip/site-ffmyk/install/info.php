<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "FFmyk", 
	'summary' => "", 
	'screenshot' => "ffmyk-install.png"
	);
