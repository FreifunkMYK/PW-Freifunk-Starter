# --- WireDatabaseBackup {"time":"2016-01-07 15:41:05","user":"","dbName":"processwire","description":"","tables":[],"excludeTables":["pages_drafts","pages_roles","permissions","roles","roles_permissions","users","users_roles","user","role","permission"],"excludeCreateTables":[],"excludeExportTables":["field_roles","field_permissions","field_email","field_pass","caches","session_login_throttle","page_path_history"]}

DROP TABLE IF EXISTS `caches`;
CREATE TABLE `caches` (
  `name` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_admin_theme`;
CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_admin_theme` (`pages_id`, `data`) VALUES('41', '161');

DROP TABLE IF EXISTS `field_alias`;
CREATE TABLE `field_alias` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_alias_repeater`;
CREATE TABLE `field_alias_repeater` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_body`;
CREATE TABLE `field_body` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_body` (`pages_id`, `data`) VALUES('27', '<h3>The page you were looking for is not found.</h3>\n\n<p>Please use our search engine or navigation above to find the page.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1', '<h2>What is ProcessWire?</h2>\r\n\r\n<p>ProcessWire gives you full control over your fields, templates and markup. It provides a powerful template system that works the way you do. Not to mention, ProcessWire\'s API makes working with your content easy and enjoyable. <a href=\"http://processwire.com\">Learn more</a></p>\r\n\r\n<h3>About this site profile</h3>\r\n\r\n<p>This is a basic minimal site for you to use in developing your own site or to learn from. There are a few pages here to serve as examples, but this site profile does not make any attempt to demonstrate all that ProcessWire can do. To learn more or ask questions, visit the <a href=\"http://www.processwire.com/talk/\" target=\"_blank\">ProcessWire forums</a> or <a href=\"http://modules.processwire.com/categories/site-profile/\">browse more site profiles</a>. If you are building a new site, this minimal profile is a good place to start. You may use these existing templates and design as they are, or you may replace them entirely.</p>\r\n\r\n<h3>Browse the site</h3>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1002', '<h2>Ut capio feugiat saepius torqueo olim</h2>\r\n\r\n<h3>In utinam facilisi eum vicis feugait nimis</h3>\r\n\r\n<p>Iusto incassum appellatio cui macto genitus vel. Lobortis aliquam luctus, roto enim, imputo wisi tamen. Ratis odio, genitus acsi, neo illum consequat consectetuer ut.</p>\r\n\r\n<blockquote>\r\n<p>Wisi fere virtus cogo, ex ut vel nullus similis vel iusto. Tation incassum adsum in, quibus capto premo diam suscipere facilisi. Uxor laoreet mos capio premo feugait ille et. Pecus abigo immitto epulae duis vel. Neque causa, indoles verto, decet ingenium dignissim.</p>\r\n</blockquote>\r\n\r\n<p>Patria iriure vel vel autem proprius indoles ille sit. Tation blandit refoveo, accumsan ut ulciscor lucidus inhibeo capto aptent opes, foras.</p>\r\n\r\n<h3>Dolore ea valde refero feugait utinam luctus</h3>\r\n\r\n<p><img alt=\"Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.\" class=\"align_left\"	src=\"/site/assets/files/1002/psych_cartoon_4-20.400x0.jpg\" />Usitas, nostrud transverbero, in, amet, nostrud ad. Ex feugiat opto diam os aliquam regula lobortis dolore ut ut quadrum. Esse eu quis nunc jugis iriure volutpat wisi, fere blandit inhibeo melior, hendrerit, saluto velit. Eu bene ideo dignissim delenit accumsan nunc. Usitas ille autem camur consequat typicus feugait elit ex accumsan nutus accumsan nimis pagus, occuro. Immitto populus, qui feugiat opto pneum letalis paratus. Mara conventio torqueo nibh caecus abigo sit eum brevitas. Populus, duis ex quae exerci hendrerit, si antehabeo nobis, consequat ea praemitto zelus.</p>\r\n\r\n<p>Immitto os ratis euismod conventio erat jus caecus sudo. code test Appellatio consequat, et ibidem ludus nulla dolor augue abdo tego euismod plaga lenis. Sit at nimis venio venio tego os et pecus enim pneum magna nobis ad pneum. Saepius turpis probo refero molior nonummy aliquam neque appellatio jus luctus acsi. Ulciscor refero pagus imputo eu refoveo valetudo duis dolore usitas. Consequat suscipere quod torqueo ratis ullamcorper, dolore lenis, letalis quia quadrum plaga minim.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1001', '<h2>Si lobortis singularis genitus ibidem saluto.</h2><p>Dolore ad nunc, mos accumsan paratus duis suscipit luptatum facilisis macto uxor iaceo quadrum. Demoveo, appellatio elit neque ad commodo ea. Wisi, iaceo, tincidunt at commoveo rusticus et, ludus. Feugait at blandit bene blandit suscipere abdo duis ideo bis commoveo pagus ex, velit. Consequat commodo roto accumsan, duis transverbero.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1004', '<h2>Pertineo vel dignissim, natu letalis fere odio</h2><p>Magna in gemino, gilvus iusto capto jugis abdo mos aptent acsi qui. Utrum inhibeo humo humo duis quae. Lucidus paulatim facilisi scisco quibus hendrerit conventio adsum.</p><h3>Si lobortis singularis genitus ibidem saluto</h3><ul><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li><li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li><li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li><li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li></ul><p>Iriure, ex velit, praesent vulpes delenit capio vero gilvus inhibeo letatio aliquip metuo qui eros. Transverbero demoveo euismod letatio torqueo melior. Ut odio in suscipit paulatim amet huic letalis suscipere eros causa, letalis magna.</p><ol><li>Feugiat eligo foras ex elit sed indoles hos elit ex antehabeo defui et nostrud.</li><li>Letatio valetudo multo consequat inhibeo ille dignissim pagus et in quadrum eum eu.</li><li>Aliquam si consequat, ut nulla amet et turpis exerci, adsum luctus ne decet, delenit.</li><li>Commoveo nunc diam valetudo cui, aptent commoveo at obruo uxor nulla aliquip augue.</li></ol>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1038', '<p>Der 3600 liegt von der Performance knapp hinter dem 1043. Dafür funkt er aber zusätzlich auch im 5GHz-Band.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1035', '<p>Der 1043 ist aktuell der performanteste Freifunk-Router. Er schafft die höchsten Datenübertragungsraten und kommt auch ohne Probleme mit vielen verbundenen Endgeräten gleichzeitig klar.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1050', 'Dies ist ein Text über die Konsole <a href=\"text.de\">Link</a>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1031', '<p>Der 841 ist wohl der meist verwendete Freifunk-Router. Zum günstigen Preis bieter er eine ordentliche Performance.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1258', '<p>Die Sektorantenne CPE210 ist sehr leistungsstark und sehr gut geeignet eine größere Anzahl an Clients zu verwalten. Möchtest du einen Platz mit Freifunk Versorgen wirst du mit der CPE210 viel Spaß haben.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1307', '<p>Die CPE210 hat von Haus aus eine eigene IP die auf der Rückseite des Geräts zu finden ist. Um das Gerät an zu steuern musst du eine Statische IP an deinem Computer einstellen.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1327', '<p>https://www.youtube.com/watch?v=7X_SXrJGupo</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1304', '<p>Das Gerät ist ein zur Zeit (März 2011) moderner Router mit</p>\n\n<ul><li>einer Atheros AR9132 CPU mit 400MHz</li>\n	<li>32MB RAM</li>\n	<li>8MB Flash-Speicher</li>\n	<li>802.11b/g/n WLAN mit bis zu 300MBps Durchsatz</li>\n	<li>drei abschraubbaren 3dBi Rundstrahl-Antennen (SMA-RP Stecker)</li>\n	<li>einem USB 2.0 Port</li>\n	<li>integriertem 4-Port Gigabitswitch</li>\n	<li>einem WAN-Port</li>\n</ul><p>Bei Bedarf kann zu Administrations- oder Wartungszwecken ein serieller Anschluss oder JTAG-Anschluss nachgerüstet werden (einfach) und man kann den aufgelöteten RAM-Chip durch einen 64MB Speicherchip austauschen (schwieriger). Weitere technische Informationen findet man auf der Seite im <a href=\"http://wiki.openwrt.org/toh/tp-link/tl-wr1043nd\" rel=\"nofollow\">OpenWrt-wiki</a>.</p>\n\n<p>Wer wasserdichte Gehäuse braucht, beachte die Ausmaße des gesamten Geräts von 20/3-14/14-18-30cm (B/H/T ohne Antennen, mit angewinkelten Antennen, mit ausgestreckten Antennen). Die Platine alleine hat Abmessungen von 16,7x3x13cm B/H/T. Das Gerät kann laut Herstellerangaben im Bereich von 0-40 Grad Celsius bei einer Luftfeuchtigkeit von 10-90% (nicht kondensierend) betrieben werden.</p>\n\n<p>Das Gerät ist damit in allen Eigenschaften moderner ausgestattet und gleichzeitig etwas günstiger und kleiner als der WRT54GL, also bei einem Neukauf zu bevorzugen.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1305', '<p>Das Gerät verwendet standardmäßig ein 12V, 1.5A Netzteil und könnte als Außengerät auch von einem passenden Blei-Gel-Akku, einem Solarpanel und Überladungsschutz betrieben werden.</p>\n\n<p>Energieverbrauch (selbst gemessen mit KD-302 von reichelt; der Hersteller gibt die Leistungsaufnahme mit 10W an):</p>\n\n<ul><li>Booten (Spitzenwert): 5,2W</li>\n	<li>Idle (ohne Verbindungen): 3,8W</li>\n	<li>Idle (mit 1-2 Rechnern ohne Traffic): 4,4W</li>\n	<li>Datenverkehr über WAN/WLAN/LAN: 4,7-5,2W</li>\n</ul><p>Der gemessene Energieverbrauch ist damit ebenfalls geringer, als beim WRT54GL. Dessen Verbrauch wird auf ca. 7W (idle) geschätzt und unter Last wurde er bei 9W gemessen.</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1390', '<p>body</p>');
INSERT INTO `field_body` (`pages_id`, `data`) VALUES('1391', '<h3>Angaben gemäß § 5 TMG:</h3>\n\n<p>Betreiber des Webauftritts<br />\nSebastian Preisner<br />\nFreifunk Mayen-Koblenz<br />\nVulkanstraße 23<br />\n53179 Bonn</p>\n\n<h3>Kontakt:</h3>\n\n<table><tbody><tr><td>E-Mail:</td>\n			<td>info@freifunk-myk.de</td>\n		</tr></tbody></table><p>Quelle: <em><a href=\"http://www.e-recht24.de\" rel=\"nofollow\">http://www.e-recht24.de</a></em></p>\n\n<p>Haftungsausschluss (Disclaimer)</p>\n\n<p><strong>Haftung für Inhalte</strong></p>\n\n<p>Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen. Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben hiervon unberührt. Eine diesbezügliche Haftung ist jedoch erst ab dem Zeitpunkt der Kenntnis einer konkreten Rechtsverletzung möglich. Bei Bekanntwerden von entsprechenden Rechtsverletzungen werden wir diese Inhalte umgehend entfernen.</p>\n\n<p><strong>Haftung für Links</strong></p>\n\n<p>Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich. Die verlinkten Seiten wurden zum Zeitpunkt der Verlinkung auf mögliche Rechtsverstöße überprüft. Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht erkennbar. Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist jedoch ohne konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Links umgehend entfernen.</p>\n\n<p><strong>Urheberrecht</strong></p>\n\n<p>Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers. Downloads und Kopien dieser Seite sind nur für den privaten, nicht kommerziellen Gebrauch gestattet. Soweit die Inhalte auf dieser Seite nicht vom Betreiber erstellt wurden, werden die Urheberrechte Dritter beachtet. Insbesondere werden Inhalte Dritter als solche gekennzeichnet. Sollten Sie trotzdem auf eine Urheberrechtsverletzung aufmerksam werden, bitten wir um einen entsprechenden Hinweis. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Inhalte umgehend entfernen.</p>\n\n<p> </p>\n\n<p>Datenschutzerklärung:</p>\n\n<p><strong>Datenschutz</strong></p>\n\n<p>Die Betreiber dieser Seiten nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.</p>\n\n<p>Die Nutzung unserer Webseite ist in der Regel ohne Angabe personenbezogener Daten möglich. Soweit auf unseren Seiten personenbezogene Daten (beispielsweise Name, Anschrift oder E-Mail-Adressen) erhoben werden, erfolgt dies, soweit möglich, stets auf freiwilliger Basis. Diese Daten werden ohne Ihre ausdrückliche Zustimmung nicht an Dritte weitergegeben.</p>\n\n<p>Wir weisen darauf hin, dass die Datenübertragung im Internet (z.B. bei der Kommunikation per E-Mail) Sicherheitslücken aufweisen kann. Ein lückenloser Schutz der Daten vor dem Zugriff durch Dritte ist nicht möglich.</p>\n\n<p> </p>\n\n<p><strong>Cookies</strong></p>\n\n<p>Die Internetseiten verwenden teilweise so genannte Cookies. Cookies richten auf Ihrem Rechner keinen Schaden an und enthalten keine Viren. Cookies dienen dazu, unser Angebot nutzerfreundlicher, effektiver und sicherer zu machen. Cookies sind kleine Textdateien, die auf Ihrem Rechner abgelegt werden und die Ihr Browser speichert.</p>\n\n<p>Die meisten der von uns verwendeten Cookies sind so genannte „Session-Cookies“. Sie werden nach Ende Ihres Besuchs automatisch gelöscht. Andere Cookies bleiben auf Ihrem Endgerät gespeichert, bis Sie diese löschen. Diese Cookies ermöglichen es uns, Ihren Browser beim nächsten Besuch wiederzuerkennen.</p>\n\n<p>Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die Annahme von Cookies für bestimmte Fälle oder generell ausschließen sowie das automatische Löschen der Cookies beim Schließen des Browser aktivieren. Bei der Deaktivierung von Cookies kann die Funktionalität dieser Website eingeschränkt sein.</p>\n\n<p> </p>\n\n<p><strong>Server-Log-Files</strong></p>\n\n<p>Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log Files, die Ihr Browser automatisch an uns übermittelt. Dies sind:</p>\n\n<ul><li>Browsertyp/ Browserversion</li>\n	<li>verwendetes Betriebssystem</li>\n	<li>Referrer URL</li>\n	<li>Hostname des zugreifenden Rechners</li>\n	<li>Uhrzeit der Serveranfrage</li>\n</ul><p><br />\nDiese Daten sind nicht bestimmten Personen zuordenbar. Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns vor, diese Daten nachträglich zu prüfen, wenn uns konkrete Anhaltspunkte für eine rechtswidrige Nutzung bekannt werden.</p>\n\n<p> </p>\n\n<p><strong>Kontaktformular</strong></p>\n\n<p>Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.</p>');

DROP TABLE IF EXISTS `field_content`;
CREATE TABLE `field_content` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_content_end`;
CREATE TABLE `field_content_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_date`;
CREATE TABLE `field_date` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` datetime NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1028', '2014-10-14 00:00:00');
INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1029', '2014-12-10 00:00:00');
INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1030', '2015-02-03 00:00:00');
INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1050', '2015-11-21 00:00:00');
INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1327', '2015-12-10 00:00:00');
INSERT INTO `field_date` (`pages_id`, `data`) VALUES('1390', '2016-01-07 00:00:00');

DROP TABLE IF EXISTS `field_email`;
CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_factory_nightly`;
CREATE TABLE `field_factory_nightly` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_factory_stable`;
CREATE TABLE `field_factory_stable` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_features`;
CREATE TABLE `field_features` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1031', '1033', '1');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1258', '1033', '2');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1031', '1034', '0');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1035', '1036', '0');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1258', '1036', '1');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1038', '1037', '2');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1038', '1039', '0');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1038', '1040', '1');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1258', '1315', '0');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1258', '1316', '3');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1035', '1324', '1');
INSERT INTO `field_features` (`pages_id`, `data`, `sort`) VALUES('1035', '1325', '2');

DROP TABLE IF EXISTS `field_firstname`;
CREATE TABLE `field_firstname` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_flash`;
CREATE TABLE `field_flash` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_flash` (`pages_id`, `data`) VALUES('1035', '8');

DROP TABLE IF EXISTS `field_headline`;
CREATE TABLE `field_headline` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('1', 'Minimal Site Profile');
INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('1001', 'About Us');
INSERT INTO `field_headline` (`pages_id`, `data`) VALUES('27', '404 Page Not Found');

DROP TABLE IF EXISTS `field_image`;
CREATE TABLE `field_image` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_image` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1031', '841n-1280_3.jpg', '0', '[null]', '2015-11-20 13:57:36', '2015-11-20 13:57:36');
INSERT INTO `field_image` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1035', '2-1043-v2.jpg', '0', '[null]', '2015-11-20 14:08:13', '2015-11-20 14:08:13');
INSERT INTO `field_image` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1038', 'tl-wdr3600-un-v1-02.jpg', '0', '[null]', '2015-11-20 15:43:46', '2015-11-20 15:43:46');

DROP TABLE IF EXISTS `field_images`;
CREATE TABLE `field_images` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1002', 'psych_cartoon_4-20.jpg', '0', 'Copyright by Austin Cramer for DesignIntelligence. This is a placeholder while he makes new ones for us.', '2014-07-25 15:30:53', '2014-07-25 15:30:39');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1028', 'kbu_weiss.png', '0', '{\"0\":null,\"1023\":\"Logo KBU Freifunk\"}', '2015-11-20 12:03:36', '2015-11-20 12:03:36');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1029', '1.jpg', '0', '[\"\"]', '2015-11-20 12:19:32', '2015-11-20 12:19:32');
INSERT INTO `field_images` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1030', 'sudhaus.png', '0', '[\"\"]', '2015-11-20 12:58:10', '2015-11-20 12:58:10');

DROP TABLE IF EXISTS `field_info`;
CREATE TABLE `field_info` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_info_blocks`;
CREATE TABLE `field_info_blocks` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_info_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1258', '1307', '1', '1306');
INSERT INTO `field_info_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1035', '1304,1305', '2', '1302');
INSERT INTO `field_info_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1038', '', '0', '1320');
INSERT INTO `field_info_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1031', '', '0', '1328');

DROP TABLE IF EXISTS `field_info_end`;
CREATE TABLE `field_info_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_info_tab`;
CREATE TABLE `field_info_tab` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_info_tab_end`;
CREATE TABLE `field_info_tab_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_key`;
CREATE TABLE `field_key` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_key` (`pages_id`, `data`) VALUES('1380', 'D978897F10BFC3818ED72B505BECF33909993AD013F16441BC90692ED2812E3C');
INSERT INTO `field_key` (`pages_id`, `data`) VALUES('1381', 'C278BC83CA8EC008A913C856906C51FDF23168E7EEB9F0A47AE1FC6A2F9EF81F');
INSERT INTO `field_key` (`pages_id`, `data`) VALUES('1383', '6B3A8CCEF9254E61B3ED07116FD2C2AC17C6C292B9008D44C85EDAFFAA3D7690');
INSERT INTO `field_key` (`pages_id`, `data`) VALUES('1384', '14B73923440A9A88E034D36F1EA477B7A2AF808E01CA12CBF7D4296FC06AD92C');
INSERT INTO `field_key` (`pages_id`, `data`) VALUES('1385', 'F38F6345307530C02B610A26E73D304147B30D8CA5E3A6DF9761A5286DF648DB');

DROP TABLE IF EXISTS `field_language`;
CREATE TABLE `field_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('40', '1016', '0');
INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('41', '1023', '0');

DROP TABLE IF EXISTS `field_language_files`;
CREATE TABLE `field_language_files` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_language_files_site`;
CREATE TABLE `field_language_files_site` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--textformatter--textformatterentities-module.json', '140', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--textformatter--textformattermarkdownextra--textformattermarkdownextra-module.json', '141', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--system--systemupdater--systemupdater-module.json', '139', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--system--systemnotifications--systemnotificationsconfig-php.json', '138', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--system--systemnotifications--systemnotifications-module.json', '137', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--session--sessionloginthrottle--sessionloginthrottle-module.json', '136', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--session--sessionhandlerdb--sessionhandlerdb-module.json', '135', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--session--sessionhandlerdb--processsessiondb-module.json', '134', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processuser--processuserconfig-php.json', '133', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processuser--processuser-module.json', '132', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processtemplate--processtemplateexportimport-php.json', '131', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processtemplate--processtemplate-module.json', '130', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processrole--processrole-module.json', '129', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processrecentpages--processrecentpages-module.json', '128', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processprofile--processprofile-module.json', '127', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpermission--processpermission-module.json', '126', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageview-module.json', '125', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagetype--processpagetype-module.json', '124', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagetrash-module.json', '123', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagesort-module.json', '122', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagesearch--processpagesearch-module.json', '121', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelister--processpagelisterbookmarks-php.json', '120', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelister--processpagelister-module.json', '119', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelist--processpagelistrenderjson-php.json', '118', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelist--processpagelistrender-php.json', '117', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelist--processpagelistactions-php.json', '116', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageeditlink--processpageeditlink-module.json', '114', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpagelist--processpagelist-module.json', '115', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageeditimageselect--processpageeditimageselect-module.json', '113', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageedit--pagebookmarks-php.json', '111', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageedit--processpageedit-module.json', '112', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageadd--processpageadd-module.json', '109', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processpageclone-module.json', '110', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processmodule--processmodule-module.json', '107', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processmodule--processmoduleinstall-php.json', '108', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processlogin--processlogin-module.json', '106', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processlogger--processlogger-module.json', '105', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processlist-module.json', '104', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processhome-module.json', '103', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processforgotpassword-module.json', '102', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processfield--processfield-module.json', '100', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processfield--processfieldexportimport-php.json', '101', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--pagerender-module.json', '98', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--process--processcommentsmanager--processcommentsmanager-module.json', '99', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--pagepaths-module.json', '97', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--markup--markuppagernav--markuppagernav-module.json', '96', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--markup--markuppagefields-module.json', '95', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--languagetabs-module.json', '93', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--processlanguage-module.json', '94', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--languagesupportpagenames-module.json', '92', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--languagesupportfields-module.json', '91', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--languageparser-php.json', '89', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--languagesupport--languagesupport-module.json', '90', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--jquery--jquerywiretabs--jquerywiretabs-module.json', '88', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldurl-module.json', '87', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldtextarea-module.json', '86', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldsubmit--inputfieldsubmit-module.json', '84', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldtext-module.json', '85', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldselector--inputfieldselector-module.json', '83', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldselectmultiple-module.json', '82', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldselect-module.json', '81', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldradios--inputfieldradios-module.json', '80', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpassword-module.json', '79', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagetitle--inputfieldpagetitle-module.json', '78', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetableajax-php.json', '77', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagename--inputfieldpagename-module.json', '75', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetable-module.json', '76', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselectmultiple-module.json', '74', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpageautocomplete--inputfieldpageautocomplete-module.json', '72', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselect-module.json', '73', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldpage--inputfieldpage-module.json', '71', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldmarkup-module.json', '69', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldname-module.json', '70', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldinteger-module.json', '68', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldicon--inputfieldicon-module.json', '66', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldimage--inputfieldimage-module.json', '67', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldhidden-module.json', '65', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldform-module.json', '64', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldfloat-module.json', '63', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldemail-module.json', '60', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldfieldset-module.json', '61', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldfile--inputfieldfile-module.json', '62', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfielddatetime--inputfielddatetime-module.json', '59', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldckeditor--inputfieldckeditor-module.json', '58', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldbutton-module.json', '55', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldcheckboxes--inputfieldcheckboxes-module.json', '57', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldcheckbox-module.json', '56', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--inputfield--inputfieldasmselect--inputfieldasmselect-module.json', '54', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeurl-module.json', '53', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypetextarea-module.json', '52', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeselector-module.json', '50', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypetext-module.json', '51', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtyperepeater--inputfieldrepeater-module.json', '49', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtyperepeater--fieldtyperepeater-module.json', '48', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypepagetable-module.json', '47', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypepage-module.json', '46', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeoptions--selectableoptionmanager-php.json', '45', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeoptions--selectableoptionconfig-php.json', '44', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeoptions--fieldtypeoptions-module.json', '43', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypemodule-module.json', '42', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypefile-module.json', '39', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypefloat-module.json', '40', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypeinteger-module.json', '41', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypefieldsettabopen-module.json', '38', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--fieldtypecomments-module.json', '35', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypedatetime-module.json', '37', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--inputfieldcommentsadmin-module.json', '36', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--commentlist-php.json', '33', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--commentnotifications-php.json', '34', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--commentform-php.json', '32', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--fieldtype--fieldtypecomments--commentfilterakismet-module.json', '31', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--admintheme--adminthemereno--default-php.json', '30', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--admintheme--adminthemereno--debug-inc.json', '29', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--admintheme--adminthemereno--adminthemerenohelpers-php.json', '28', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--admintheme--adminthemereno--adminthemereno-module.json', '27', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--modules--admintheme--adminthemedefault--adminthemedefault-module.json', '26', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--wireupload-php.json', '25', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--wiretempdir-php.json', '24', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--wirehttp-php.json', '23', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--sessioncsrf-php.json', '21', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--wirecache-php.json', '22', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--session-php.json', '20', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--sanitizer-php.json', '19', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--process-php.json', '18', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--permissions-php.json', '17', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--password-php.json', '16', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--pages-php.json', '14', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--paginatedarray-php.json', '15', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--modulesduplicates-php.json', '12', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--pageimage-php.json', '13', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--modules-php.json', '11', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--inputfield-php.json', '9', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--inputfieldwrapper-php.json', '10', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--functions-php.json', '8', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--fieldtypemulti-php.json', '6', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--filevalidatormodule-php.json', '7', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--fieldtype-php.json', '5', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--fieldselectorinfo-php.json', '4', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--fieldgroups-php.json', '2', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--fields-php.json', '3', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--field-php.json', '1', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--core--admintheme-php.json', '0', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--templates-admin--debug-inc.json', '142', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'wire--templates-admin--default-php.json', '143', '[\"\"]', '2015-11-20 00:00:24', '2015-11-20 00:00:24');
INSERT INTO `field_language_files_site` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1023', 'site--modules--ldaphelper-module.json', '144', '[null]', '2015-12-12 12:30:52', '2015-12-12 12:30:52');

DROP TABLE IF EXISTS `field_lastconnection`;
CREATE TABLE `field_lastconnection` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` datetime NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_lastconnection` (`pages_id`, `data`) VALUES('1381', '2016-01-07 14:22:01');
INSERT INTO `field_lastconnection` (`pages_id`, `data`) VALUES('1380', '2016-01-07 14:22:01');
INSERT INTO `field_lastconnection` (`pages_id`, `data`) VALUES('1384', '2016-01-07 14:22:01');
INSERT INTO `field_lastconnection` (`pages_id`, `data`) VALUES('1382', '2016-01-05 22:41:01');
INSERT INTO `field_lastconnection` (`pages_id`, `data`) VALUES('1385', '2016-01-07 14:22:01');

DROP TABLE IF EXISTS `field_lastname`;
CREATE TABLE `field_lastname` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_latitude`;
CREATE TABLE `field_latitude` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_latitude` (`pages_id`, `data`) VALUES('1381', '50.369116');
INSERT INTO `field_latitude` (`pages_id`, `data`) VALUES('1380', '50.369074');
INSERT INTO `field_latitude` (`pages_id`, `data`) VALUES('1384', '50.654149');
INSERT INTO `field_latitude` (`pages_id`, `data`) VALUES('1382', '50.369176231678');
INSERT INTO `field_latitude` (`pages_id`, `data`) VALUES('1385', '50.3816203');

DROP TABLE IF EXISTS `field_logo`;
CREATE TABLE `field_logo` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_longitude`;
CREATE TABLE `field_longitude` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_longitude` (`pages_id`, `data`) VALUES('1381', '7.566802');
INSERT INTO `field_longitude` (`pages_id`, `data`) VALUES('1380', '7.56669');
INSERT INTO `field_longitude` (`pages_id`, `data`) VALUES('1384', '7.188039');
INSERT INTO `field_longitude` (`pages_id`, `data`) VALUES('1382', '7.5669785423278');
INSERT INTO `field_longitude` (`pages_id`, `data`) VALUES('1385', '7.4137049');

DROP TABLE IF EXISTS `field_navigation`;
CREATE TABLE `field_navigation` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_nightly`;
CREATE TABLE `field_nightly` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_nightly_end`;
CREATE TABLE `field_nightly_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_node_firmware`;
CREATE TABLE `field_node_firmware` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_node_hardware`;
CREATE TABLE `field_node_hardware` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_on_page_blocks`;
CREATE TABLE `field_on_page_blocks` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_on_page_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('27', '', '0', '1376');
INSERT INTO `field_on_page_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1391', '', '0', '1392');
INSERT INTO `field_on_page_blocks` (`pages_id`, `data`, `count`, `parent_id`) VALUES('1002', '', '0', '1400');

DROP TABLE IF EXISTS `field_online`;
CREATE TABLE `field_online` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` tinyint(4) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_online` (`pages_id`, `data`) VALUES('1381', '1');
INSERT INTO `field_online` (`pages_id`, `data`) VALUES('1380', '1');
INSERT INTO `field_online` (`pages_id`, `data`) VALUES('1384', '1');
INSERT INTO `field_online` (`pages_id`, `data`) VALUES('1385', '1');

DROP TABLE IF EXISTS `field_pass`;
CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;

DROP TABLE IF EXISTS `field_permissions`;
CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_process`;
CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `data` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_process` (`pages_id`, `data`) VALUES('6', '17');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('3', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('8', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('9', '14');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('10', '7');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('11', '47');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('16', '48');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('300', '104');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('21', '50');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('29', '66');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('23', '10');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('304', '138');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('31', '136');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('22', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('30', '68');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('303', '129');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('2', '87');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('302', '121');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('301', '109');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('28', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1007', '150');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1009', '158');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1011', '159');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1015', '163');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1017', '164');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1024', '165');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1056', '175');

DROP TABLE IF EXISTS `field_public_key`;
CREATE TABLE `field_public_key` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_public_key` (`pages_id`, `data`) VALUES('41', 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC2bbsrZLJ2271iSb04qpoUDlbrH19aTXUlzFaQSp1KO0BjCxdNvY1x6ZjkIPUC0YeaVGePu0cBJFWYZKpPRiz5hbWeFgaVvhbAlhxAMSlgdjLiN2alc92mBX40NhrpgSV/hGB5KAqqBQr9y01g9I5GRl9jdXgzUA9hhbqxls6tvXxGN2SJC3TFbUj+2PPpn8Cw2ZJiKsKZIoQfs9ZQuv2xDi7E6voqBALlYWd217ZgBezklrpm48dDisGI/WdZyllgk0XyxXwRSSD8QINTPjWmKXk5ZNH65J0KyDlnrZsgQuQbsN3jGgJsPfR6tydVITd1IXtSwawUYZ+JU8wwp6CR sebastian@gartenzwerk');

DROP TABLE IF EXISTS `field_ram`;
CREATE TABLE `field_ram` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_ram` (`pages_id`, `data`) VALUES('1035', '32');

DROP TABLE IF EXISTS `field_render_options`;
CREATE TABLE `field_render_options` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_roles`;
CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_router_firmware`;
CREATE TABLE `field_router_firmware` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_canonical`;
CREATE TABLE `field_seo_canonical` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_custom`;
CREATE TABLE `field_seo_custom` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_description`;
CREATE TABLE `field_seo_description` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_image`;
CREATE TABLE `field_seo_image` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_keywords`;
CREATE TABLE `field_seo_keywords` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_tab`;
CREATE TABLE `field_seo_tab` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_tab_end`;
CREATE TABLE `field_seo_tab_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_title`;
CREATE TABLE `field_seo_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_sidebar`;
CREATE TABLE `field_sidebar` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_sidebar` (`pages_id`, `data`) VALUES('1', '<h3>About ProcessWire</h3>\n\n<p>ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients.</p>\n\n<ul><li><a href=\"http://processwire.com/talk/\">Support</a></li>\n	<li><a href=\"http://processwire.com/docs/\">Documentation</a></li>\n	<li><a href=\"http://processwire.com/docs/tutorials/\">Tutorials</a></li>\n	<li><a href=\"http://cheatsheet.processwire.com\">API Cheatsheet</a></li>\n	<li><a href=\"http://modules.processwire.com\">Modules/Plugins</a></li>\n</ul>');
INSERT INTO `field_sidebar` (`pages_id`, `data`) VALUES('1002', '<h3>Sudo nullus</h3>\r\n\r\n<p>Et torqueo vulpes vereor luctus augue quod consectetuer antehabeo causa patria tation ex plaga ut. Abluo delenit wisi iriure eros feugiat probo nisl aliquip nisl, patria. Antehabeo esse camur nisl modo utinam. Sudo nullus ventosus ibidem facilisis saepius eum sino pneum, vicis odio voco opto.</p>');

DROP TABLE IF EXISTS `field_slider`;
CREATE TABLE `field_slider` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_slider` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1', 'liebfrauenkirche_2ap.png', '1', '{\"0\":\"Erweiter das Netz in deiner Umgebung\",\"1023\":\"Erweiter das Netz in deiner Umgebung\"}', '2015-11-20 18:14:44', '2015-11-20 12:38:59');
INSERT INTO `field_slider` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1', 'img_1417.jpg', '0', '{\"0\":\"Bleib mobil mit Freifunk\",\"1023\":\"Bleib mobil mit Freifunk\"}', '2015-11-20 18:36:19', '2015-11-20 12:38:59');

DROP TABLE IF EXISTS `field_stable`;
CREATE TABLE `field_stable` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_stable_end`;
CREATE TABLE `field_stable_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_subtitle`;
CREATE TABLE `field_subtitle` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_subtitle` (`pages_id`, `data`) VALUES('1380', 'ffmyk-clostersudhaus-1');
INSERT INTO `field_subtitle` (`pages_id`, `data`) VALUES('1381', 'ffmyk-clostersudhaus-3');
INSERT INTO `field_subtitle` (`pages_id`, `data`) VALUES('1384', 'kreativmonkey-ffmyk');
INSERT INTO `field_subtitle` (`pages_id`, `data`) VALUES('1382', 'ffmyk-clostersudhaus-2');
INSERT INTO `field_subtitle` (`pages_id`, `data`) VALUES('1385', 'ffmyk-adlerweb-a0f3c18f9b98');

DROP TABLE IF EXISTS `field_summary`;
CREATE TABLE `field_summary` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1002', 'Dolore ea valde refero feugait utinam luctus. Probo velit commoveo et, delenit praesent, suscipit zelus, hendrerit zelus illum facilisi, regula. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1001', 'This is a placeholder page with two child pages to serve as an example. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1005', 'View this template\'s source for a demonstration of how to create a basic site map. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1004', 'Mos erat reprobo in praesent, mara premo, obruo iustum pecus velit lobortis te sagaciter populus.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1', 'ProcessWire is an open source CMS and web application framework aimed at the needs of designers, developers and their clients. ');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1028', 'Nach Kontakt mit den Freifunkern aus der Region Köln/Bonn entschieden sich einige Interessierte, auch in unserer Region einen lokalen Ableger zu gründen.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1029', 'Es wurden die ersten Router zum Testen unseres Netzwerks aufgesetzt und getestet.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1030', 'Im Closter Sudhaus in der Trier Str. 105 in Koblenz-Metternich gingen die ersten Freifunk-Knoten in einer öffentlichen Gaststätte in Betrieb');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1031', 'Der TP-Link TL-WR841N ist das typische Einstiegsmodel in das Thema Freifunk. Es ist für 15-25€ erhältlich und passt somit zu jedem Geldbeutel. Mit seiner hohen Reichweite ist der TL-WR841N auch sehr gut geeignet um größere Fläschen mit Freifunk ab zu decken. Leider stößt er jedoch durch seinen kleinen Flashspeicher und genügsamen Processor auch schnell an seine Grenzen.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1035', 'Der 1043 ist aktuell der performanteste Freifunk-Router. Er schafft die höchsten Datenübertragungsraten und kommt auch ohne Probleme mit vielen verbundenen Endgeräten gleichzeitig klar.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1038', 'Der 3600 liegt von der Performance knapp hinter dem 1043. Dafür funkt er aber zusätzlich auch im 5GHz-Band.');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1050', 'Test');
INSERT INTO `field_summary` (`pages_id`, `data`) VALUES('1390', 'kurz');

DROP TABLE IF EXISTS `field_sysupgread_nightly`;
CREATE TABLE `field_sysupgread_nightly` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_sysupgread_stable`;
CREATE TABLE `field_sysupgread_stable` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_timeline`;
CREATE TABLE `field_timeline` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` tinyint(4) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_timeline` (`pages_id`, `data`) VALUES('1028', '1');
INSERT INTO `field_timeline` (`pages_id`, `data`) VALUES('1029', '1');
INSERT INTO `field_timeline` (`pages_id`, `data`) VALUES('1030', '1');

DROP TABLE IF EXISTS `field_title`;
CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_title` (`pages_id`, `data`) VALUES('11', 'Templates');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('16', 'Fields');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('22', 'Setup');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('3', 'Pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('6', 'Add Page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('8', 'Tree');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('9', 'Save Sort');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('10', 'Edit');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('21', 'Modules');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('29', 'Users');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('30', 'Roles');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('2', 'Admin');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('7', 'Trash');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('27', '404 Page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('302', 'Insert Link');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('23', 'Login');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('304', 'Profile');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('301', 'Empty Trash');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('300', 'Search');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('303', 'Insert Image');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('28', 'Access');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('31', 'Permissions');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('32', 'Edit pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('34', 'Delete pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('35', 'Move pages (change parent)');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('36', 'View pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('50', 'Sort child pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('51', 'Change templates on pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('52', 'Administer users');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('53', 'User can update profile/password');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('54', 'Lock or unlock a page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1', 'Home');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1001', 'About');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1002', 'Child page example 1');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1000', 'Search');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1004', 'Child page example 2');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1005', 'Site Map');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1006', 'Use Page Lister');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1007', 'Find');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1009', 'Recent');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1010', 'Can see recently edited pages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1011', 'Logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1012', 'Can view system logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1013', 'Can manage system logs');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1014', 'Administer languages and static translation files');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1015', 'Languages');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1016', 'Default');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1017', 'Language Translator');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1315', 'Sectorantenne');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1019', 'Blog');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1020', 'Routerliste');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1311', '1043');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1022', 'Features');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1023', 'Deutsch');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1024', 'Upgrades');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1027', 'Site-Settings');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1028', 'Erstes Vernetzungstreffen');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1029', 'Einrichtung der ersten Router');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1030', 'Erste Knoten in Gaststätten');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1031', 'TL-WR841N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1032', 'TP-Link');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1033', 'Hohe Reichweite');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1034', 'Sehr günstig');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1035', 'TL-WR1043ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1036', 'Hohe Performance');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1037', 'USB-Anschluss');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1038', 'TL-WDR3600');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1039', 'Abgekündigt');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1040', 'DualBand');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1041', 'Repeaters');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1042', 'Buffalo');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1043', 'D-Link');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1044', 'Netgear');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1045', 'Allnet');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1046', 'Ubiquiti');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1047', 'Unbekannt');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1048', 'tl-wr841-v2');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1396', 'about');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1050', 'Von der Konsole');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1056', 'Access Overview');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1057', 'registration');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1355', '510');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1067', 'alias_repeater');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1265', 'TL-MR3420');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1266', 'TL-WA701N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1267', 'TL-WA750RE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1268', 'TL-WA801N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1269', 'TL-WA830RE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1270', 'TL-WA850RE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1271', 'TL-WA860RE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1272', 'TL-WA901N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1273', 'TL-WDR3500');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1274', 'TL-WDR4300');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1275', 'TL-WDR4900');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1276', 'TL-WR1043N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1277', 'TL-WR2543N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1278', 'TL-WR703N');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1279', 'TL-WR710N');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1280', 'TL-WR740N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1281', 'TL-WR741N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1282', 'TL-WR743N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1297', 'Block');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1284', 'TL-WR842N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1285', 'TL-WR941N-ND');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1286', 'Generic');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1287', 'GENERIC');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1288', 'Kvm');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1289', 'KVM');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1290', 'Virtualbox');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1291', 'VIRTUALBOX');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1292', 'Vmware');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1293', 'VMWARE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1316', 'PoE');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1317', 'on_page_blocks');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1327', 'ARD Berichtet über Freifunk');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1304', 'Hardware Eigenschaften');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1320', 'tl-wdr3600');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1324', 'Abschraubbare Antennen');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1325', 'USB 2.0 Port');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1305', 'Energiedaten');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1328', 'tl-wr841n-nd');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1337', 'Mitmachen');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1338', 'mitmachen');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1342', 'Node');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1351', '520');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1175', 'WNDRMAC');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1174', 'WNDR4300');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1173', 'WNDR3800');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1172', 'WNDR3700');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1361', '220');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1360', 'home');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1373', 'kreativmonkey');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1388', 'Testtitel');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1298', 'home');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1302', 'tl-wr1043nd');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1306', '210');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1307', 'Installationshinweis');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1264', 'TL-MR3220');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1263', 'TL-MR3040');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1262', 'TL-MR3020');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1261', 'CPE520');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1260', 'CPE510');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1259', 'CPE220');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1258', 'CPE210');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1257', 'WRT160NL');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1256', 'Linksys');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1234', 'BULLET-M');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1235', 'LOCO-M');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1236', 'LOCO-M-XW');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1237', 'NANOSTATION-M');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1238', 'NANOSTATION-M-XW');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1239', 'PICOSTATION-M');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1240', 'ROCKET-M');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1241', 'UNIFIAP-OUTDOOR');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1242', 'UNIFI-AP-PRO');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1243', 'UNIFI');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1255', 'DIR-825');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1254', 'DIR-615');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1253', 'WZR-HP-G450H');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1252', 'WZR-HP-AG300H-WZR-600DHP');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1392', 'impressum');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1391', 'Impressum');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1390', 'Test');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1376', 'http404');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1380', 'E8:94:F6:F5:80:64');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1381', 'C4:6E:1F:2D:9F:34');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1382', 'C4:6E:1F:2D:9F:0E');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1383', '30:B5:C2:B9:0E:12');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1384', 'E8:94:F6:D4:4D:0C');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1385', 'A0:F3:C1:8F:9B:98');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1389', 'Add Page');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1400', 'what');
INSERT INTO `field_title` (`pages_id`, `data`) VALUES('1404', '1004.1001.1_background');

DROP TABLE IF EXISTS `field_video`;
CREATE TABLE `field_video` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_website`;
CREATE TABLE `field_website` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1032', 'http://www.tp-link.de');
INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1042', 'http://www.buffalo-technology.de');
INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1043', 'http://www.dlink.com/de/de/home-solutions/connect/routers');
INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1044', 'http://www.netgear.de');
INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1045', 'http://www.allnet.de');
INSERT INTO `field_website` (`pages_id`, `data`) VALUES('1046', 'https://www.ubnt.com/');

DROP TABLE IF EXISTS `fieldgroups`;
CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups` (`id`, `name`) VALUES('2', 'admin');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('3', 'user');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('4', 'role');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('5', 'permission');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('1', 'home');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('88', 'sitemap');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('83', 'basic-page');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('80', 'search');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('97', 'language');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('98', 'hersteller');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('99', 'list_firmware');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('100', 'list_hersteller');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('101', 'list_router');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('102', 'node');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('103', 'router');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('104', 'features');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('105', 'list_features');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('106', 'post');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('107', 'router_firmware');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('108', 'list_blog');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('109', 'site-setting');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('110', 'registration');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('111', 'edit_page');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('112', 'repeater_alias_repeater');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('113', 'repeater_Block');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('114', 'repeater_on_page_blocks');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('115', 'list_nodes');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('116', 'node_operator');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('118', '404');

DROP TABLE IF EXISTS `fieldgroups_fields`;
CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fields_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '2', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '135', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('4', '5', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('5', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '92', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '123', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('80', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '128', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '76', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '129', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('88', '79', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '146', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('88', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '146', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '3', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '98', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '99', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '110', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('99', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '76', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '112', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '109', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('100', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '153', '10', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '128', '15', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('104', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('105', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '134', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '76', '3', '{\"description\":\"Eine f\\u00fcr den DAU verst\\u00e4ndliche Kurzbeschreibung des Routers. Was macht ihn besonders? Wof\\u00fcr ist er gut geeignet? Was ist zu beachten?\",\"label\":\"Beschreibung\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '126', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '44', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '141', '5', '{\"description\":\"Weiterf\\u00fchrende Informationen: Installationshinweis, Bastelvorschl\\u00e4ge, Zusatzinformationen zur Hardware.\",\"label\":\"Weitere Informationen\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '143', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '144', '7', '{\"columnWidth\":30}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '110', '8', '{\"adminThumbs\":1}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '128', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '130', '9', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '131', '10', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '129', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '117', '2', '{\"columnWidth\":50,\"description\":\"Soll dieser Artikel in der Timeline angezeigt werden?\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '79', '3', '{\"collapsed\":\"5\",\"required\":1,\"requiredIf\":\"timeline=1\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '76', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '44', '5', '{\"description1023\":\"Das erste Bild wird als Titelbild verwendet.\",\"label1023\":\"Bilder\",\"required\":1,\"requiredIf\":\"timeline=1\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '126', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '116', '1', '{\"columnWidth\":50,\"required\":1}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '105', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '120', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '103', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '121', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '118', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '106', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '104', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('107', '119', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '136', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('109', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('109', '111', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '44', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '79', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '132', '12', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '127', '13', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('106', '133', '11', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '130', '9', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '78', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '79', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '76', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '126', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '128', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '129', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '130', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '131', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '133', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '132', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('108', '127', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '112', '12', '{\"label\":\"OpenWRT Wiki\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '129', '16', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '130', '17', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '131', '18', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '138', '11', '{\"columnWidth\":50}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '115', '9', '{\"description\":\"Eine Liste an Ausstattungsmerkmalen.\",\"notes\":\"Bitte nach Wichtigkeit\\/Besonderheit sortieren.\",\"required\":1}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '137', '10', '{\"columnWidth\":50}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('110', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '107', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '4', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '100', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '97', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('111', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '133', '19', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '132', '20', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '127', '21', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('112', '139', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('113', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '82', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('113', '76', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '145', '13', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '126', '14', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '142', '0', '{\"collapsed\":\"9\",\"columnWidth\":70}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('103', '1', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('113', '44', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('114', '76', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('114', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('114', '111', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '78', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '44', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '131', '10', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '133', '11', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '132', '12', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('83', '127', '13', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '155', '6', '{\"collapsed\":\"7\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '148', '7', '{\"collapsed\":\"7\",\"maxlength\":2048}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '111', '1', '{\"label\":\"Name\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '124', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '152', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '150', '4', '{\"collapsed\":\"7\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '154', '5', '{\"collapsed\":\"7\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('115', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('116', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('114', '110', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('114', '147', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '78', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '79', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '76', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '146', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '44', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '126', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '128', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '129', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '130', '9', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '131', '10', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '133', '11', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '132', '12', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('118', '127', '13', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '151', '9', '{\"collapsed\":\"7\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '149', '8', '{\"collapsed\":\"7\",\"maxlength\":2048}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('102', '1', '0', '{\"label\":\"Mac Adresse\",\"pattern\":\"^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$\"}');

DROP TABLE IF EXISTS `fields`;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii NOT NULL,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;

INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('1', 'FieldtypePageTitle', 'title', '13', 'Title', '{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('2', 'FieldtypeModule', 'process', '25', 'Process', '{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('3', 'FieldtypePassword', 'pass', '24', 'Set Password', '{\"collapsed\":1,\"size\":50,\"maxlength\":128}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('5', 'FieldtypePage', 'permissions', '24', 'Permissions', '{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('4', 'FieldtypePage', 'roles', '24', 'Roles', '{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('92', 'FieldtypeEmail', 'email', '9', 'E-Mail Address', '{\"size\":70,\"maxlength\":255}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('82', 'FieldtypeTextarea', 'sidebar', '0', 'Sidebar', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":5,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\r\\nNumberedList, BulletedList, -, Blockquote\\r\\nPWLink, Unlink, Anchor\\r\\nPWImage, Table, HorizontalRule, SpecialChar\\r\\nPasteText, PasteFromWord\\r\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8],\"collapsed\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('44', 'FieldtypeImage', 'images', '0', 'Images', '{\"extensions\":\"gif jpg jpeg png\",\"adminThumbs\":1,\"inputfieldClass\":\"InputfieldImage\",\"maxFiles\":0,\"descriptionRows\":1,\"fileSchema\":2,\"textformatters\":[\"TextformatterEntities\"],\"outputFormat\":1,\"defaultValuePage\":0,\"defaultGrid\":0,\"icon\":\"camera\",\"collapsed\":0,\"noLang\":1,\"maxReject\":0,\"send_templates\":[29,1,52,49],\"unzip\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('79', 'FieldtypeTextarea', 'summary', '1', 'Summary', '{\"textformatters\":[\"TextformatterEntities\"],\"inputfieldClass\":\"InputfieldTextarea\",\"collapsed\":2,\"rows\":3,\"contentType\":0,\"label1023\":\"Kurzbeschreibung\",\"send_templates\":[29,1,52,49,34]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('76', 'FieldtypeTextarea', 'body', '0', 'Body', '{\"inputfieldClass\":\"InputfieldCKEditor\",\"rows\":10,\"contentType\":1,\"toolbar\":\"Format, Bold, Italic, -, RemoveFormat\\nNumberedList, BulletedList, -, Blockquote\\nPWLink, Unlink, Anchor\\nPWImage, Table, HorizontalRule, SpecialChar\\nPasteText, PasteFromWord\\nScayt, -, Sourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4;h5;h6;pre;address\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[2,4,8],\"textformatters\":[\"TextformatterVideoEmbed\"],\"collapsed\":0,\"send_templates\":[29,44,1,52,59,60,49]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('78', 'FieldtypeText', 'headline', '0', 'Headline', '{\"description\":\"Use this instead of the Title if a longer headline is needed than what you want to appear in navigation.\",\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":2,\"size\":0,\"maxlength\":1024}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('97', 'FieldtypeModule', 'admin_theme', '8', 'Admin Theme', '{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('98', 'FieldtypeFile', 'language_files_site', '24', 'Site Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for translations specific to your site (like files in \\/site\\/templates\\/ for example).\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('99', 'FieldtypeFile', 'language_files', '24', 'Core Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for [language packs](http:\\/\\/modules.processwire.com\\/categories\\/language-pack\\/). To delete all files, double-click the trash can for any file, then save.\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('100', 'FieldtypePage', 'language', '24', 'Language', '{\"derefAsPage\":1,\"parent_id\":1015,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldRadios\",\"required\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('119', 'FieldtypeFieldsetClose', 'nightly_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'nightly\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\",\"tags\":\"Firmware\",\"send_templates\":[53]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('103', 'FieldtypeFile', 'sysupgread_stable', '0', 'Sysupgread Stable', '{\"extensions\":\"pdf doc docx xls xlsx gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldFile\",\"descriptionRows\":1,\"tags\":\"Firmware\",\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('104', 'FieldtypeFile', 'sysupgread_nightly', '0', 'Sysupgread Nightly', '{\"extensions\":\"pdf doc docx xls xlsx gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldFile\",\"descriptionRows\":1,\"tags\":\"Firmware\",\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('105', 'FieldtypeFile', 'factory_stable', '0', 'Factory Stable', '{\"extensions\":\"pdf doc docx xls xlsx gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldFile\",\"descriptionRows\":1,\"tags\":\"Firmware\",\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('106', 'FieldtypeFile', 'factory_nightly', '0', 'Factory Nightly', '{\"extensions\":\"pdf doc docx xls xlsx gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldFile\",\"descriptionRows\":1,\"tags\":\"Firmware\",\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('118', 'FieldtypeFieldsetOpen', 'nightly', '0', 'Nightly', '{\"collapsed\":0,\"tags\":\"Firmware\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('107', 'FieldtypeText', 'public_key', '0', 'Public Key', '{\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"tags\":\"User\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('109', 'FieldtypeImage', 'logo', '0', 'Logo', '{\"extensions\":\"gif jpg jpeg png\",\"maxFiles\":1,\"outputFormat\":1,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"descriptionRows\":1,\"defaultGrid\":0,\"maxReject\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('110', 'FieldtypeImage', 'image', '0', 'Image', '{\"extensions\":\"gif jpg jpeg png\",\"maxFiles\":1,\"outputFormat\":1,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"descriptionRows\":1,\"defaultGrid\":0,\"maxReject\":0,\"icon\":\"camera-retro\",\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('111', 'FieldtypeText', 'subtitle', '0', 'Subtitle', '{\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":2,\"size\":0,\"maxlength\":1024}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('112', 'FieldtypeURL', 'website', '0', 'Webseite', '{\"textformatters\":[\"TextformatterEntities\"],\"noRelative\":0,\"addRoot\":0,\"collapsed\":0,\"size\":0,\"maxlength\":1024}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('127', 'FieldtypeFieldsetClose', 'seo_tab_END', '0', 'Close an open fieldset', '{\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('114', 'FieldtypePage', 'router_firmware', '0', 'Firmware', '{\"derefAsPage\":0,\"collapsed\":0,\"parent_id\":0,\"labelFieldName\":\".\",\"inputfield\":\"InputfieldSelect\",\"tags\":\"Router\",\"labelFieldFormat\":\"{title}\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('115', 'FieldtypePage', 'features', '0', 'Features', '{\"derefAsPage\":0,\"collapsed\":0,\"parent_id\":1022,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldPageAutocomplete\",\"tags\":\"Router\",\"template_id\":50,\"labelFieldFormat\":\"{title}\",\"usePageEdit\":0,\"send_templates\":[49],\"operator\":\"*=\",\"searchFields\":\"title\",\"addable\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('126', 'FieldtypeFieldsetTabOpen', 'seo_tab', '0', 'SEO', '{\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('116', 'FieldtypeDatetime', 'date', '0', 'Datum', '{\"dateOutputFormat\":\"j M Y\",\"collapsed\":0,\"size\":25,\"datepicker\":3,\"dateInputFormat\":\"d-m-Y\",\"send_templates\":[52]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('117', 'FieldtypeCheckbox', 'timeline', '0', 'Timeline', '{\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('120', 'FieldtypeFieldsetOpen', 'stable', '0', 'Stable', '{\"collapsed\":0,\"tags\":\"Firmware\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('121', 'FieldtypeFieldsetClose', 'stable_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'stable\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\",\"tags\":\"Firmware\",\"send_templates\":[53]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('122', 'FieldtypePage', 'navigation', '0', 'Navigation', '{\"label1023\":\"Navigation\",\"derefAsPage\":0,\"collapsed\":0,\"parent_id\":0,\"labelFieldName\":\".\",\"labelFieldFormat\":\"{title}\",\"inputfield\":\"InputfieldAsmSelect\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('123', 'FieldtypeImage', 'slider', '0', 'Slider', '{\"extensions\":\"gif jpg jpeg png\",\"maxFiles\":0,\"outputFormat\":1,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"descriptionRows\":1,\"defaultGrid\":0,\"maxReject\":0,\"icon\":\"instagram\",\"fileSchema\":2,\"collapsed\":0,\"send_templates\":[1]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('124', 'FieldtypeText', 'key', '0', 'Key', '{\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"pattern\":\"^[A-Fa-f0-9]{64}$\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('128', 'FieldtypeText', 'seo_title', '0', 'Title', '{\"description\":\"A good length for a title is 60 characters.\",\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('129', 'FieldtypeText', 'seo_keywords', '0', 'Keywords', '{\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('130', 'FieldtypeText', 'seo_description', '0', 'Description', '{\"description\":\"A good length for a description is 160 characters.\",\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('131', 'FieldtypeText', 'seo_image', '0', 'Image', '{\"description\":\"Please enter the URL (including &quot;http:\\/\\/...&quot;) to a preview image.\",\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('132', 'FieldtypeText', 'seo_canonical', '0', 'Canonical Link', '{\"notes\":\"The URL should include &quot;http:\\/\\/...&quot;.\",\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('133', 'FieldtypeTextarea', 'seo_custom', '0', 'Custom', '{\"description\":\"If you want to add other meta tags, you can do it here.\",\"notes\":\"Please use this schema: name := content. One tag per line. Special characters are only allowed in the content part and get converted to HTML.\",\"tags\":\"seo\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('134', 'FieldtypeText', 'video', '0', 'Video', '{\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"tags\":\"Router\",\"textformatters\":[\"TextformatterVideoEmbed\"]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('135', 'FieldtypeText', 'firstname', '0', '', '{\"label1023\":\"Vorname\",\"collapsed\":0,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('136', 'FieldtypeText', 'lastname', '0', '', '{\"label1023\":\"Nachname\",\"size\":0,\"maxlength\":2048,\"collapsed\":0,\"tags\":\"User\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('137', 'FieldtypeInteger', 'flash', '0', 'Flash', '{\"zeroNotEmpty\":0,\"collapsed\":0,\"inputType\":\"text\",\"tags\":\"Router\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('138', 'FieldtypeInteger', 'ram', '0', 'RAM', '{\"zeroNotEmpty\":0,\"collapsed\":0,\"inputType\":\"text\",\"tags\":\"Router\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('139', 'FieldtypeText', 'alias', '0', 'Alias', '{\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"tags\":\"Router\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('140', 'FieldtypeRepeater', 'alias_repeater', '0', 'Alias', '{\"template_id\":58,\"parent_id\":1067,\"repeaterReadyItems\":3,\"repeaterFields\":[139],\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('141', 'FieldtypeRepeater', 'info_blocks', '0', 'Seitenblock', '{\"template_id\":59,\"parent_id\":1297,\"repeaterReadyItems\":3,\"repeaterFields\":{\"0\":1,\"2\":76,\"3\":44},\"collapsed\":0,\"send_templates\":[49]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('142', 'FieldtypeFieldsetOpen', 'content', '0', 'Content', '{\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('143', 'FieldtypeFieldsetClose', 'content_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'content\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('144', 'FieldtypeFieldsetOpen', 'info', '0', 'Informationen', '');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('145', 'FieldtypeFieldsetClose', 'info_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'info\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('146', 'FieldtypeRepeater', 'on_page_blocks', '0', 'Page Blocks', '{\"template_id\":60,\"parent_id\":1317,\"repeaterReadyItems\":3,\"repeaterFields\":[1,111,76,110,147],\"collapsed\":0,\"send_templates\":[29,1]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('147', 'FieldtypeOptions', 'render_options', '0', 'Anzeige Optionen', '{\"inputfieldClass\":\"InputfieldSelect\",\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('148', 'FieldtypeText', 'latitude', '0', 'Latitude', '{\"precision\":2,\"zeroNotEmpty\":0,\"inputType\":\"text\",\"tags\":\"Node\",\"send_templates\":[48]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('149', 'FieldtypeText', 'longitude', '0', 'Longitude', '{\"precision\":2,\"zeroNotEmpty\":0,\"inputType\":\"text\",\"tags\":\"Node\",\"send_templates\":[48]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('150', 'FieldtypeDatetime', 'lastconnection', '0', 'Last Connection', '{\"label1023\":\"Letzte Verbindung\",\"collapsed\":0,\"size\":25,\"datepicker\":0,\"dateInputFormat\":\"Y-m-d\",\"tags\":\"Node\",\"dateOutputFormat\":\"j F Y H:i:s\",\"send_templates\":[48],\"timeInputFormat\":\"H:i\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('151', 'FieldtypeCheckbox', 'online', '0', 'Online', '{\"collapsed\":0,\"tags\":\"Node\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('152', 'FieldtypeFieldsetTabOpen', 'info_tab', '0', 'Infos', '{\"collapsed\":0,\"tags\":\"Node\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('153', 'FieldtypeFieldsetClose', 'info_tab_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'info_tab\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('154', 'FieldtypeText', 'node_hardware', '0', 'Hardware', '{\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"tags\":\"Node\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('155', 'FieldtypeText', 'node_firmware', '0', 'Firmware', '{\"size\":0,\"maxlength\":2048,\"tags\":\"Node\",\"collapsed\":0}');

DROP TABLE IF EXISTS `fieldtype_options`;
CREATE TABLE `fieldtype_options` (
  `fields_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `title` text,
  `value` varchar(255) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fields_id`,`option_id`),
  UNIQUE KEY `title` (`title`(255),`fields_id`),
  KEY `value` (`value`,`fields_id`),
  KEY `sort` (`sort`,`fields_id`),
  FULLTEXT KEY `title_value` (`title`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('125', '1', 'Home', '', '0');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '1', 'Zeige zuerst den Text und dann das Bild', '', '0');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '2', 'Zeige das Bild zuerst und dann den Text', '', '1');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '3', 'Zeige ausschließlich den Text (zentriert)', '', '2');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '4', 'Setze das Bild als Hintergrundbild', '', '3');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '5', 'Zeige ausschließlich den Text (rechtsbündig)', '', '4');
INSERT INTO `fieldtype_options` (`fields_id`, `option_id`, `title`, `value`, `sort`) VALUES('147', '6', 'Zeige den Text und das Bild an zweiter stelle (center)', '', '5');

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM AUTO_INCREMENT=180 DEFAULT CHARSET=utf8;

INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('1', 'FieldtypeTextarea', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('2', 'FieldtypeNumber', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('3', 'FieldtypeText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('4', 'FieldtypePage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('30', 'InputfieldForm', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('6', 'FieldtypeFile', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('7', 'ProcessPageEdit', '1', '{\"bookmarks\":{\"_0\":[1019]}}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('10', 'ProcessLogin', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('12', 'ProcessPageList', '0', '{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('121', 'ProcessPageEditLink', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('14', 'ProcessPageSort', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('15', 'InputfieldPageListSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('117', 'JqueryUI', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('17', 'ProcessPageAdd', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('125', 'SessionLoginThrottle', '11', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('122', 'InputfieldPassword', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('25', 'InputfieldAsmSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('116', 'JqueryCore', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('27', 'FieldtypeModule', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('28', 'FieldtypeDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('29', 'FieldtypeEmail', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('108', 'InputfieldURL', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('32', 'InputfieldSubmit', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('33', 'InputfieldWrapper', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('34', 'InputfieldText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('35', 'InputfieldTextarea', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('36', 'InputfieldSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('37', 'InputfieldCheckbox', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('38', 'InputfieldCheckboxes', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('39', 'InputfieldRadios', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('40', 'InputfieldHidden', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('41', 'InputfieldName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('43', 'InputfieldSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('45', 'JqueryWireTabs', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('46', 'ProcessPage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('47', 'ProcessTemplate', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('48', 'ProcessField', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('50', 'ProcessModule', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('114', 'PagePermissions', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('97', 'FieldtypeCheckbox', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('115', 'PageRender', '3', '{\"clearCache\":1}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('55', 'InputfieldFile', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('56', 'InputfieldImage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('57', 'FieldtypeImage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('60', 'InputfieldPage', '0', '{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\",\"InputfieldPageAutocomplete\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('61', 'TextformatterEntities', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('66', 'ProcessUser', '0', '{\"showFields\":[\"name\",\"email\",\"roles\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('67', 'MarkupAdminDataTable', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('68', 'ProcessRole', '0', '{\"showFields\":[\"name\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('76', 'ProcessList', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('78', 'InputfieldFieldset', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('79', 'InputfieldMarkup', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('80', 'InputfieldEmail', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('89', 'FieldtypeFloat', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('83', 'ProcessPageView', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('84', 'FieldtypeInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('85', 'InputfieldInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('86', 'InputfieldPageName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('87', 'ProcessHome', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('90', 'InputfieldFloat', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('94', 'InputfieldDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('98', 'MarkupPagerNav', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('129', 'ProcessPageEditImageSelect', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('103', 'JqueryTableSorter', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('104', 'ProcessPageSearch', '1', '{\"searchFields\":\"title\",\"displayField\":\"title path\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('105', 'FieldtypeFieldsetOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('106', 'FieldtypeFieldsetClose', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('107', 'FieldtypeFieldsetTabOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('109', 'ProcessPageTrash', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('111', 'FieldtypePageTitle', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('112', 'InputfieldPageTitle', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('113', 'MarkupPageArray', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('131', 'InputfieldButton', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('133', 'FieldtypePassword', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('134', 'ProcessPageType', '1', '{\"showFields\":[]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('135', 'FieldtypeURL', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('136', 'ProcessPermission', '1', '{\"showFields\":[\"name\",\"title\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('137', 'InputfieldPageListSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('138', 'ProcessProfile', '1', '{\"profileFields\":[\"pass\",\"email\",\"admin_theme\",\"language\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('139', 'SystemUpdater', '1', '{\"systemVersion\":13,\"coreVersion\":\"2.7.0\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('148', 'AdminThemeDefault', '10', '{\"colors\":\"classic\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('149', 'InputfieldSelector', '10', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('150', 'ProcessPageLister', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('151', 'JqueryMagnific', '1', '', '2014-07-21 07:21:45');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('152', 'PagePathHistory', '3', '', '2014-07-25 09:36:57');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('155', 'InputfieldCKEditor', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('156', 'MarkupHTMLPurifier', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('158', 'ProcessRecentPages', '1', '', '2015-11-18 22:28:34');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('159', 'ProcessLogger', '1', '', '2015-11-18 22:28:54');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('160', 'InputfieldIcon', '0', '', '2015-11-18 22:28:54');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('161', 'AdminThemeReno', '10', '{\"colors\":\"\",\"avatar_field_user\":\"\",\"userFields_user\":\"name\",\"notices\":\"fa-bell\",\"home\":\"fa-home\",\"signout\":\"fa-power-off\",\"page\":\"fa-file-text\",\"setup\":\"fa-wrench\",\"module\":\"fa-briefcase\",\"access\":\"fa-unlock\"}', '2015-11-18 22:31:34');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('162', 'LanguageSupport', '3', '{\"languagesPageID\":1015,\"defaultLanguagePageID\":1016,\"otherLanguagePageIDs\":[1023],\"languageTranslatorPageID\":1017}', '2015-11-18 23:37:09');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('163', 'ProcessLanguage', '1', '', '2015-11-18 23:37:09');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('164', 'ProcessLanguageTranslator', '1', '', '2015-11-18 23:37:09');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('165', 'ProcessWireUpgrade', '1', '', '2015-11-19 23:51:40');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('166', 'ProcessWireUpgradeCheck', '11', '{\"useLoginHook\":\"1\"}', '2015-11-19 23:51:40');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('179', 'AllInOneMinify', '3', '{\"stylesheet_prefix\":\"css_\",\"javascript_prefix\":\"js_\",\"max_cache_lifetime\":\"2419200\",\"html_minify\":1,\"development_mode\":\"\",\"directory_traversal\":1,\"empty_cache\":\"Empty cache\",\"domain_sharding\":\"\",\"domain_sharding_ssl\":\"\"}', '2015-12-27 11:59:57');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('178', 'LazyCron', '3', '', '2015-12-15 03:10:27');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('169', 'InputfieldPageAutocomplete', '0', '', '2015-11-20 12:50:15');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('170', 'FieldtypeRepeater', '3', '{\"repeatersRootPageID\":1041}', '2015-11-20 16:00:10');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('171', 'InputfieldRepeater', '0', '', '2015-11-20 16:00:10');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('172', 'FieldtypeOptions', '1', '', '2015-11-24 20:47:21');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('173', 'MarkupSEO', '2', '{\"includeTemplates\":[\"list_blog\",\"post\",\"router\",\"basic-page\"],\"author\":\"Freifunk-Myk\",\"sitename\":\"Freifunk-Myk\",\"useParents\":\"\",\"title\":\"\",\"titleSmart\":[\"headline\",\"title\"],\"keywords\":\"\",\"keywordsSmart\":[\"features\"],\"description\":\"\",\"descriptionSmart\":[\"summary\"],\"image\":\"\",\"imageSmart\":[\"image\",\"images\"],\"titleFormat\":\"\",\"canonicalProtocol\":\"https\",\"custom\":\"\",\"robots\":[\"noindex\"],\"hardLimit\":1,\"titleLimit\":60,\"descriptionLimit\":160,\"includeGenerator\":1,\"includeOpenGraph\":1,\"includeTwitter\":1,\"twitterUsername\":\"@ffmyk\",\"method\":\"auto\",\"addWhitespace\":1,\"googleAnalytics\":\"\",\"piwikAnalyticsUrl\":\"\",\"piwikAnalyticsIDSite\":\"\"}', '2015-11-24 23:35:53');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('174', 'TextformatterVideoEmbed', '1', '{\"maxWidth\":640,\"maxHeight\":480,\"responsive\":1,\"clearCache\":\"\"}', '2015-11-26 18:41:12');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('175', 'ProcessAccessOverview', '1', '{\"usedRoles\":[\"admin\",\"guest\",\"manager\",\"superuser\",\"user\"],\"showSystem\":1,\"showPaths\":1}', '2015-11-27 09:15:46');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('176', 'EmailVerification', '0', '', '2015-11-27 09:24:07');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('177', 'ldapHelper', '3', '{\"host\":\"10.0.1.4\",\"useSSL\":\"\",\"useV3\":1,\"loginDomain\":\"ffmyk.de\",\"admin\":\"cn=root,dc=ffmyk,dc=de\",\"secret\":\"L2EAPrNef4vAJP76ZPTpB2e5\",\"userDefaultRoles\":[1026],\"debug\":\"\",\"ldapSetting\":\"objectclass: top\\nobjectclass: person\\nobjectclass: organizationalPerson\\nobjectclass: inetorgperson\\nuid: @benutzername@\\ncn: @firstname@\\nsn: @lastname@\\ngivenName: @benutzername@\\nuserPassword: @password@\\ndescription: @description@\"}', '2015-12-11 12:40:11');

DROP TABLE IF EXISTS `page_path_history`;
CREATE TABLE `page_path_history` (
  `path` varchar(255) NOT NULL,
  `pages_id` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`path`),
  KEY `pages_id` (`pages_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `templates_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET ascii NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `published` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=1405 DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1', '0', '1', 'home', '9', '2015-12-14 21:24:20', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('2', '1', '2', 'processwire', '1035', '2015-11-18 22:28:54', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('3', '2', '2', 'page', '21', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('6', '3', '2', 'add', '21', '2015-11-18 22:30:14', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('7', '1', '2', 'trash', '1039', '2011-08-14 22:04:52', '41', '2010-02-07 05:29:39', '2', '2010-02-07 05:29:39', '12');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('8', '3', '2', 'list', '21', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('9', '3', '2', 'sort', '1047', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('10', '3', '2', 'edit', '21', '2015-11-18 22:30:20', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('11', '22', '2', 'template', '21', '2011-03-29 21:37:06', '41', '2010-02-01 11:04:54', '2', '2010-02-01 11:04:54', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('16', '22', '2', 'field', '21', '2011-03-29 21:37:06', '41', '2010-02-01 12:44:07', '2', '2010-02-01 12:44:07', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('21', '2', '2', 'module', '21', '2011-03-29 21:37:06', '41', '2010-02-02 10:02:24', '2', '2010-02-02 10:02:24', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('22', '2', '2', 'setup', '21', '2011-03-29 21:37:06', '41', '2010-02-09 12:16:59', '2', '2010-02-09 12:16:59', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('23', '2', '2', 'login', '1035', '2011-05-03 23:38:10', '41', '2010-02-17 09:59:39', '2', '2010-02-17 09:59:39', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('27', '1', '64', 'http404', '1035', '2015-12-15 01:31:09', '41', '2010-06-03 06:53:03', '3', '2010-06-03 06:53:03', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('28', '2', '2', 'access', '13', '2011-05-03 23:38:10', '41', '2011-03-19 19:14:20', '2', '2011-03-19 19:14:20', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('29', '28', '2', 'users', '29', '2011-04-05 00:39:08', '41', '2011-03-19 19:15:29', '2', '2011-03-19 19:15:29', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('30', '28', '2', 'roles', '29', '2011-04-05 00:38:39', '41', '2011-03-19 19:15:45', '2', '2011-03-19 19:15:45', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('31', '28', '2', 'permissions', '29', '2011-04-05 00:53:52', '41', '2011-03-19 19:16:00', '2', '2011-03-19 19:16:00', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('32', '31', '5', 'page-edit', '25', '2011-09-06 15:34:24', '41', '2011-03-19 19:17:03', '2', '2011-03-19 19:17:03', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('34', '31', '5', 'page-delete', '25', '2011-09-06 15:34:33', '41', '2011-03-19 19:17:23', '2', '2011-03-19 19:17:23', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('35', '31', '5', 'page-move', '25', '2011-09-06 15:34:48', '41', '2011-03-19 19:17:41', '2', '2011-03-19 19:17:41', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('36', '31', '5', 'page-view', '25', '2011-09-06 15:34:14', '41', '2011-03-19 19:17:57', '2', '2011-03-19 19:17:57', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('37', '30', '4', 'guest', '25', '2011-04-05 01:37:19', '41', '2011-03-19 19:18:41', '2', '2011-03-19 19:18:41', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('38', '30', '4', 'superuser', '25', '2011-08-17 14:34:39', '41', '2011-03-19 19:18:55', '2', '2011-03-19 19:18:55', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('41', '29', '3', 'kreativmonkey', '1', '2015-11-24 00:55:58', '40', '2011-03-19 19:41:26', '2', '2011-03-19 19:41:26', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('40', '29', '3', 'guest', '25', '2015-11-18 23:37:10', '41', '2011-03-20 17:31:59', '2', '2011-03-20 17:31:59', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('50', '31', '5', 'page-sort', '25', '2011-09-06 15:34:58', '41', '2011-03-26 22:04:50', '41', '2011-03-26 22:04:50', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('51', '31', '5', 'page-template', '25', '2011-09-06 15:35:09', '41', '2011-03-26 22:25:31', '41', '2011-03-26 22:25:31', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('52', '31', '5', 'user-admin', '25', '2011-09-06 15:35:42', '41', '2011-03-30 00:06:47', '41', '2011-03-30 00:06:47', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('53', '31', '5', 'profile-edit', '1', '2011-08-16 22:32:48', '41', '2011-04-26 00:02:22', '41', '2011-04-26 00:02:22', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('54', '31', '5', 'page-lock', '1', '2011-08-15 17:48:12', '41', '2011-08-15 17:45:48', '41', '2011-08-15 17:45:48', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('300', '3', '2', 'search', '1045', '2011-03-29 21:37:06', '41', '2010-08-04 05:23:59', '2', '2010-08-04 05:23:59', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('301', '3', '2', 'trash', '1047', '2011-03-29 21:37:06', '41', '2010-09-28 05:39:30', '2', '2010-09-28 05:39:30', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('302', '3', '2', 'link', '1041', '2011-03-29 21:37:06', '41', '2010-10-01 05:03:56', '2', '2010-10-01 05:03:56', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('303', '3', '2', 'image', '1041', '2011-03-29 21:37:06', '41', '2010-10-13 03:56:48', '2', '2010-10-13 03:56:48', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('304', '2', '2', 'profile', '1025', '2011-05-03 23:38:10', '41', '2011-04-25 23:57:18', '41', '2011-04-25 23:57:18', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1000', '1', '26', 'search', '1025', '2015-11-19 22:34:44', '41', '2010-09-06 05:05:28', '2', '2010-09-06 05:05:28', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1001', '7', '29', '1001.1.5_about', '8193', '2016-01-07 14:24:15', '41', '2010-10-25 22:39:33', '2', '2010-10-25 22:39:33', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1002', '7', '29', '1002.1001.0_what', '8193', '2016-01-07 14:24:06', '41', '2010-10-25 23:21:34', '2', '2010-10-25 23:21:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1004', '7', '29', '1004.1001.1_background', '8193', '2016-01-07 14:24:12', '41', '2010-11-29 22:11:36', '2', '2010-11-29 22:11:36', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1005', '1', '34', 'site-map', '1', '2015-11-19 22:34:36', '41', '2010-11-30 21:16:49', '2', '2010-11-30 21:16:49', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1006', '31', '5', 'page-lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1007', '3', '2', 'lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1009', '3', '2', 'recent-pages', '1', '2015-11-18 22:28:34', '40', '2015-11-18 22:28:34', '40', '2015-11-18 22:28:34', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1010', '31', '5', 'page-edit-recent', '1', '2015-11-18 22:28:34', '40', '2015-11-18 22:28:34', '40', '2015-11-18 22:28:34', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1011', '22', '2', 'logs', '1', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1012', '31', '5', 'logs-view', '1', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1013', '31', '5', 'logs-edit', '1', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '40', '2015-11-18 22:28:54', '12');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1014', '31', '5', 'lang-edit', '1', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1015', '22', '2', 'languages', '16', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1016', '1015', '43', 'default', '16', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1017', '22', '2', 'language-translator', '1040', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '41', '2015-11-18 23:37:09', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1323', '1320', '59', '1449684919-11-3', '3073', '2015-12-09 18:15:19', '41', '2015-12-09 18:15:19', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1324', '1022', '50', 'abschraubbare-antennen', '1', '2015-12-10 21:07:17', '41', '2015-12-10 21:07:17', '41', '2015-12-10 21:07:17', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1019', '1', '54', 'blog', '1', '2015-11-19 22:36:14', '41', '2015-11-19 22:36:01', '41', '2015-11-19 22:36:06', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1020', '1', '47', 'router', '1', '2015-11-20 14:32:13', '41', '2015-11-19 22:36:38', '41', '2015-11-19 22:36:40', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1022', '1', '51', 'features', '1025', '2015-11-19 22:51:39', '41', '2015-11-19 22:51:08', '41', '2015-11-19 22:51:21', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1023', '1015', '43', 'deutsch', '1', '2015-12-12 11:30:52', '41', '2015-11-19 23:00:14', '41', '2015-11-19 23:00:14', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1024', '22', '2', 'upgrades', '1', '2015-11-19 23:51:40', '41', '2015-11-19 23:51:40', '41', '2015-11-19 23:51:40', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1026', '30', '4', 'user', '1', '2015-11-20 08:26:48', '41', '2015-11-20 08:26:04', '41', '2015-11-20 08:26:35', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1027', '1', '55', 'site-settings', '1025', '2015-11-20 17:46:07', '41', '2015-11-20 09:06:45', '41', '2015-11-20 09:06:48', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1028', '1019', '52', 'erstes-vernetzungstreffen', '1', '2015-11-20 11:51:56', '41', '2015-11-20 11:01:36', '41', '2015-11-20 11:03:36', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1029', '1019', '52', 'einrichtung-der-ersten-router', '1', '2015-11-20 11:19:32', '41', '2015-11-20 11:18:30', '41', '2015-11-20 11:19:32', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1030', '1019', '52', 'erste-knoten-in-gaststatten', '1', '2015-11-20 11:58:10', '41', '2015-11-20 11:57:25', '41', '2015-11-20 11:58:10', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1031', '1032', '49', 'tl-wr841n-nd', '1', '2015-12-13 17:48:17', '41', '2015-11-20 12:45:24', '41', '2015-11-20 12:57:36', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1032', '1020', '44', 'tp-link', '1', '2015-11-20 14:31:55', '41', '2015-11-20 12:45:42', '41', '2015-11-20 12:45:47', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1033', '1022', '50', 'hohe-reichweite', '1', '2015-11-20 12:57:36', '41', '2015-11-20 12:57:36', '41', '2015-11-20 12:57:36', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1034', '1022', '50', 'sehr-gunstig', '1', '2015-11-20 12:57:36', '41', '2015-11-20 12:57:36', '41', '2015-11-20 12:57:36', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1035', '1032', '49', 'tl-wr1043nd', '1', '2015-12-10 21:33:10', '41', '2015-11-20 13:06:41', '41', '2015-11-20 13:08:13', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1036', '1022', '50', 'hohe-performance', '1', '2015-11-20 13:08:13', '41', '2015-11-20 13:08:13', '41', '2015-11-20 13:08:13', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1037', '1022', '50', 'usb-anschluss', '1', '2015-11-20 13:08:13', '41', '2015-11-20 13:08:13', '41', '2015-11-20 13:08:13', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1038', '1032', '49', 'tl-wdr3600', '1', '2015-12-10 21:32:41', '41', '2015-11-20 14:41:20', '41', '2015-11-20 14:43:46', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1039', '1022', '50', '2.5ghz-5ghz', '1', '2015-11-29 10:25:33', '1055', '2015-11-20 14:43:46', '41', '2015-11-20 14:43:46', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1040', '1022', '50', 'dualband', '1', '2015-11-20 14:50:10', '41', '2015-11-20 14:50:10', '41', '2015-11-20 14:50:10', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1041', '2', '2', 'repeaters', '1036', '2015-11-20 16:00:10', '41', '2015-11-20 16:00:10', '41', '2015-11-20 16:00:10', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1042', '1020', '44', 'buffalo', '1', '2015-11-21 00:12:38', '41', '2015-11-21 00:12:26', '41', '2015-11-21 00:12:38', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1043', '1020', '44', 'd-link', '1', '2015-11-21 00:14:13', '41', '2015-11-21 00:14:05', '41', '2015-11-21 00:14:13', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1044', '1020', '44', 'netgear', '1', '2015-11-21 00:14:49', '41', '2015-11-21 00:14:39', '41', '2015-11-21 00:14:49', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1045', '1020', '44', 'allnet', '1', '2015-11-21 00:15:18', '41', '2015-11-21 00:15:11', '41', '2015-11-21 00:15:18', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1046', '1020', '44', 'ubiquiti', '1', '2015-11-21 00:16:44', '41', '2015-11-21 00:16:40', '41', '2015-11-21 00:16:44', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1047', '1020', '44', 'unbekannt', '1025', '2015-11-21 00:17:09', '41', '2015-11-21 00:17:04', '41', '2015-11-21 00:17:09', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1048', '1031', '53', 'tl-wr841-v2', '2049', '2015-11-21 21:04:24', '41', '2015-11-21 21:04:24', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1050', '1019', '52', 'von-der-konsole', '1', '2015-11-21 21:59:52', '41', '2015-11-21 21:58:47', '41', '2015-11-21 21:59:52', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1053', '30', '4', 'manager', '1', '2015-11-23 22:11:17', '41', '2015-11-23 22:02:43', '41', '2015-11-23 22:03:41', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1054', '30', '4', 'admin', '1', '2015-11-23 22:10:52', '41', '2015-11-23 22:10:38', '41', '2015-11-23 22:10:52', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1056', '22', '2', 'accessoverview', '1', '2015-11-27 09:15:46', '41', '2015-11-27 09:15:46', '41', '2015-11-27 09:15:46', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1057', '1', '56', 'registration', '1', '2015-11-27 11:34:28', '41', '2015-11-27 11:07:52', '41', '2015-11-27 11:34:28', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1338', '1317', '2', 'for-page-1337', '17', '2015-12-13 20:31:35', '41', '2015-12-13 20:31:35', '41', '2015-12-13 20:31:35', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1067', '1041', '2', 'for-field-140', '17', '2015-11-30 23:15:37', '41', '2015-11-30 23:15:37', '41', '2015-11-30 23:15:37', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1356', '1355', '59', '1450125836-6449-1', '3073', '2015-12-14 20:43:56', '41', '2015-12-14 20:43:56', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1337', '1', '29', 'mitmachen', '2049', '2015-12-13 17:53:42', '41', '2015-12-13 17:53:42', '41', NULL, '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1239', '1046', '49', 'picostationm', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1240', '1046', '49', 'rocketm', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1238', '1046', '49', 'nanostationmxw', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1236', '1046', '49', 'locomxw', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1237', '1046', '49', 'nanostationm', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1234', '1046', '49', 'bulletm', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1235', '1046', '49', 'locom', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1258', '1032', '49', '210', '1', '2015-12-06 10:53:55', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1259', '1032', '49', '220', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1260', '1032', '49', '510', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1261', '1032', '49', '520', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1262', '1032', '49', '3020', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1263', '1032', '49', '3040', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1264', '1032', '49', '3220', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1265', '1032', '49', '3420', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1266', '1032', '49', '701', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1267', '1032', '49', '750', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '12');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1268', '1032', '49', '801', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1269', '1032', '49', '830', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '14');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1270', '1032', '49', '850', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '15');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1271', '1032', '49', '860', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '16');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1272', '1032', '49', '901', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '17');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1273', '1032', '49', '3500', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '18');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1274', '1032', '49', '4300', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '19');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1275', '1032', '49', '4900', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '20');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1276', '1032', '49', '1043', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '21');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1277', '1032', '49', '2543', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '22');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1278', '1032', '49', '703', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '23');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1279', '1032', '49', '710', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '24');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1280', '1032', '49', '740', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '25');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1281', '1032', '49', '741', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '26');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1282', '1032', '49', '743', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '27');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1342', '1', '61', 'node', '1', '2015-12-14 23:57:20', '41', '2015-12-14 17:24:10', '41', '2015-12-14 17:24:17', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1284', '1032', '49', '842', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '29');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1285', '1032', '49', '941', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '30');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1286', '1020', '44', 'eneric', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1287', '1286', '49', 'generic', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1288', '1020', '44', 'vm', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1289', '1288', '49', 'kvm', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1290', '1020', '44', 'irtualbox', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '10');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1291', '1290', '49', 'virtualbox', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1292', '1020', '44', 'mware', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '11');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1293', '1292', '49', 'vmware', '1', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '41', '2015-12-01 15:28:34', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1297', '1041', '2', 'for-field-141', '17', '2015-12-06 10:29:12', '41', '2015-12-06 10:29:12', '41', '2015-12-06 10:29:12', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1298', '1297', '2', 'for-page-1', '17', '2015-12-06 10:45:22', '41', '2015-12-06 10:45:22', '41', '2015-12-06 10:45:22', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1299', '1298', '59', '1449398722-6608-1', '3073', '2015-12-06 10:45:22', '41', '2015-12-06 10:45:22', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1300', '1298', '59', '1449398722-6713-2', '3073', '2015-12-06 10:45:22', '41', '2015-12-06 10:45:22', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1301', '1298', '59', '1449398722-6795-3', '3073', '2015-12-06 10:45:22', '41', '2015-12-06 10:45:22', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1302', '1297', '2', 'for-page-1035', '17', '2015-12-06 10:45:56', '41', '2015-12-06 10:45:56', '41', '2015-12-06 10:45:56', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1326', '1302', '59', '1449781638-0929-1', '3073', '2015-12-10 21:07:18', '41', '2015-12-10 21:07:18', '41', NULL, '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1304', '1302', '59', '1449398757-0151-2', '1', '2015-12-10 21:07:17', '41', '2015-12-06 10:45:57', '41', '2015-12-09 16:32:10', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1305', '1302', '59', '1449398757-0267-3', '1', '2015-12-10 21:12:10', '41', '2015-12-06 10:45:57', '41', '2015-12-10 21:07:17', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1306', '1297', '2', 'for-page-1258', '17', '2015-12-06 10:46:59', '41', '2015-12-06 10:46:59', '41', '2015-12-06 10:46:59', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1307', '1306', '59', '1449398819-1066-1', '1', '2015-12-06 10:49:52', '41', '2015-12-06 10:46:59', '41', '2015-12-06 10:49:52', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1308', '1306', '59', '1449398819-1203-2', '3073', '2015-12-06 10:46:59', '41', '2015-12-06 10:46:59', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1309', '1306', '59', '1449398819-1318-3', '3073', '2015-12-06 10:46:59', '41', '2015-12-06 10:46:59', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1310', '1306', '59', '1449398992-7316-1', '3073', '2015-12-06 10:49:52', '41', '2015-12-06 10:49:52', '41', NULL, '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1311', '1297', '2', 'for-page-1276', '17', '2015-12-06 10:51:34', '41', '2015-12-06 10:51:34', '41', '2015-12-06 10:51:34', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1312', '1311', '59', '1449399094-5892-1', '3073', '2015-12-06 10:51:34', '41', '2015-12-06 10:51:34', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1313', '1311', '59', '1449399094-6013-2', '3073', '2015-12-06 10:51:34', '41', '2015-12-06 10:51:34', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1314', '1311', '59', '1449399094-6117-3', '3073', '2015-12-06 10:51:34', '41', '2015-12-06 10:51:34', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1315', '1022', '50', 'sectorantenne', '1', '2015-12-06 10:53:55', '41', '2015-12-06 10:53:55', '41', '2015-12-06 10:53:55', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1316', '1022', '50', 'poe', '1', '2015-12-06 10:53:55', '41', '2015-12-06 10:53:55', '41', '2015-12-06 10:53:55', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1317', '1041', '2', 'for-field-146', '17', '2015-12-06 11:05:22', '41', '2015-12-06 11:05:22', '41', '2015-12-06 11:05:22', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1318', '1302', '59', '1449678730-613-1', '3073', '2015-12-09 16:32:10', '41', '2015-12-09 16:32:10', '41', NULL, '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1319', '1302', '59', '1449678730-6249-2', '3073', '2015-12-09 16:32:10', '41', '2015-12-09 16:32:10', '41', NULL, '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1320', '1297', '2', 'for-page-1038', '17', '2015-12-09 18:15:19', '41', '2015-12-09 18:15:19', '41', '2015-12-09 18:15:19', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1321', '1320', '59', '1449684919-0859-1', '3073', '2015-12-09 18:15:19', '41', '2015-12-09 18:15:19', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1322', '1320', '59', '1449684919-0989-2', '3073', '2015-12-09 18:15:19', '41', '2015-12-09 18:15:19', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1175', '1044', '49', 'wndrmac', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1174', '1044', '49', 'wndr4300', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1172', '1044', '49', 'wndr3700', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1173', '1044', '49', 'wndr3800', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1325', '1022', '50', 'usb-2.0-port', '1', '2015-12-10 21:07:17', '41', '2015-12-10 21:07:17', '41', '2015-12-10 21:07:17', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1327', '1019', '52', 'ard-berichtet-uber-freifunk', '1', '2015-12-10 21:29:01', '41', '2015-12-10 21:25:21', '41', '2015-12-10 21:25:50', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1328', '1297', '2', 'for-page-1031', '17', '2015-12-10 21:33:43', '41', '2015-12-10 21:33:43', '41', '2015-12-10 21:33:43', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1329', '1328', '59', '1449783223-7102-1', '3073', '2015-12-10 21:33:43', '41', '2015-12-10 21:33:43', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1339', '1338', '60', '1450038695-0341-1', '3073', '2015-12-13 20:31:35', '41', '2015-12-13 20:31:35', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1340', '1338', '60', '1450038695-0566-2', '3073', '2015-12-13 20:31:35', '41', '2015-12-13 20:31:35', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1341', '1338', '60', '1450038695-0656-3', '3073', '2015-12-13 20:31:35', '41', '2015-12-13 20:31:35', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1241', '1046', '49', 'unifiapoutdoor', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1242', '1046', '49', 'unifiappro', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1243', '1046', '49', 'unifi', '1', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '41', '2015-12-01 15:09:32', '9');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1257', '1256', '49', '160', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1255', '1043', '49', '825', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1256', '1020', '44', 'linksys', '1', '2015-12-01 15:23:22', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1254', '1043', '49', '615', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1252', '1042', '49', '300-600', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1253', '1042', '49', '450', '1', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '41', '2015-12-01 15:18:32', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1330', '1328', '59', '1449783223-7178-2', '3073', '2015-12-10 21:33:43', '41', '2015-12-10 21:33:43', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1331', '1328', '59', '1449783223-7247-3', '3073', '2015-12-10 21:33:43', '41', '2015-12-10 21:33:43', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1355', '1297', '2', 'for-page-1260', '17', '2015-12-14 20:43:56', '41', '2015-12-14 20:43:56', '41', '2015-12-14 20:43:56', '7');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1354', '1351', '59', '1450125797-9177-3', '3073', '2015-12-14 20:43:17', '41', '2015-12-14 20:43:17', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1351', '1297', '2', 'for-page-1261', '17', '2015-12-14 20:43:17', '41', '2015-12-14 20:43:17', '41', '2015-12-14 20:43:17', '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1352', '1351', '59', '1450125797-8958-1', '3073', '2015-12-14 20:43:17', '41', '2015-12-14 20:43:17', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1353', '1351', '59', '1450125797-9078-2', '3073', '2015-12-14 20:43:17', '41', '2015-12-14 20:43:17', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1357', '1355', '59', '1450125836-6561-2', '3073', '2015-12-14 20:43:56', '41', '2015-12-14 20:43:56', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1358', '1355', '59', '1450125836-6657-3', '3073', '2015-12-14 20:43:56', '41', '2015-12-14 20:43:56', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1360', '1317', '2', 'for-page-1', '17', '2015-12-14 21:24:20', '41', '2015-12-14 21:24:20', '41', '2015-12-14 21:24:20', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1361', '1297', '2', 'for-page-1259', '17', '2015-12-14 22:34:50', '41', '2015-12-14 22:34:50', '41', '2015-12-14 22:34:50', '8');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1362', '1361', '59', '1450132490-0157-1', '3073', '2015-12-14 22:34:50', '41', '2015-12-14 22:34:50', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1363', '1361', '59', '1450132490-0288-2', '3073', '2015-12-14 22:34:50', '41', '2015-12-14 22:34:50', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1364', '1361', '59', '1450132490-0402-3', '3073', '2015-12-14 22:34:50', '41', '2015-12-14 22:34:50', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1365', '1360', '60', '1450133202-9253-1', '3073', '2015-12-14 22:46:42', '41', '2015-12-14 22:46:42', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1366', '1360', '60', '1450133202-9417-2', '3073', '2015-12-14 22:46:42', '41', '2015-12-14 22:46:42', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1367', '1360', '60', '1450133202-9529-3', '3073', '2015-12-14 22:46:42', '41', '2015-12-14 22:46:42', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1373', '1342', '62', 'kreativmonkey', '1', '2015-12-14 23:51:44', '41', '2015-12-14 23:51:44', '41', '2015-12-14 23:51:44', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1388', '7', '52', '1388.1019.5_testtitel', '10241', '2016-01-07 13:01:55', '41', '2016-01-07 13:01:19', '41', NULL, '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1389', '7', '52', '1389.1019.5_add-page', '10241', '2016-01-07 13:26:39', '41', '2016-01-07 13:02:15', '41', NULL, '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1390', '1019', '52', 'test', '2049', '2016-01-07 13:04:17', '1055', '2016-01-07 13:02:53', '1055', NULL, '6');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1391', '1', '29', 'impressum', '1', '2016-01-07 14:22:42', '41', '2016-01-07 13:43:03', '41', '2016-01-07 13:44:07', '13');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1376', '1317', '2', 'for-page-27', '17', '2015-12-14 23:56:20', '41', '2015-12-14 23:56:20', '41', '2015-12-14 23:56:20', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1377', '1376', '60', '1450137380-0182-1', '3073', '2015-12-14 23:56:20', '41', '2015-12-14 23:56:20', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1378', '1376', '60', '1450137380-0295-2', '3073', '2015-12-14 23:56:20', '41', '2015-12-14 23:56:20', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1379', '1376', '60', '1450137380-0385-3', '3073', '2015-12-14 23:56:20', '41', '2015-12-14 23:56:20', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1393', '1392', '60', '1452174183-708-1', '3073', '2016-01-07 13:43:03', '41', '2016-01-07 13:43:03', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1380', '1373', '48', 'e8-94-f6-f5-80-64', '1', '2016-01-07 14:22:02', '41', '2015-12-15 01:35:05', '41', '2015-12-15 01:35:05', '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1381', '1373', '48', 'c4-6e-1f-2d-9f-34', '1', '2016-01-07 14:22:02', '41', '2015-12-15 01:53:40', '41', '2015-12-15 01:53:40', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1382', '1373', '48', 'c4-6e-1f-2d-9f-0e', '1', '2016-01-07 14:22:03', '41', '2015-12-15 01:54:35', '41', '2015-12-15 01:54:35', '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1383', '1373', '48', '30-b5-c2-b9-0e-12', '1', '2015-12-15 01:55:18', '41', '2015-12-15 01:55:18', '41', '2015-12-15 01:55:18', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1384', '1373', '48', 'e8-94-f6-d4-4d-0c', '1', '2016-01-07 14:22:02', '41', '2015-12-15 01:56:30', '41', '2015-12-15 01:56:30', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1385', '1373', '48', 'a0-f3-c1-8f-9b-98', '1', '2016-01-07 14:22:02', '41', '2015-12-15 03:07:50', '41', '2015-12-15 03:07:50', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1392', '1317', '2', 'for-page-1391', '17', '2016-01-07 13:43:03', '41', '2016-01-07 13:43:03', '41', '2016-01-07 13:43:03', '3');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1394', '1392', '60', '1452174183-7291-2', '3073', '2016-01-07 13:43:03', '41', '2016-01-07 13:43:03', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1395', '1392', '60', '1452174183-7409-3', '3073', '2016-01-07 13:43:03', '41', '2016-01-07 13:43:03', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1396', '1317', '2', 'for-page-1001', '17', '2016-01-07 14:12:58', '41', '2016-01-07 14:12:58', '41', '2016-01-07 14:12:58', '4');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1397', '1396', '60', '1452175978-1901-1', '3073', '2016-01-07 14:12:58', '41', '2016-01-07 14:12:58', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1398', '1396', '60', '1452175978-2046-2', '3073', '2016-01-07 14:12:58', '41', '2016-01-07 14:12:58', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1399', '1396', '60', '1452175978-2166-3', '3073', '2016-01-07 14:12:58', '41', '2016-01-07 14:12:58', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1400', '1317', '2', 'for-page-1002', '17', '2016-01-07 14:13:58', '41', '2016-01-07 14:13:58', '41', '2016-01-07 14:13:58', '5');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1401', '1400', '60', '1452176038-7424-1', '3073', '2016-01-07 14:13:58', '41', '2016-01-07 14:13:58', '41', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1402', '1400', '60', '1452176038-7573-2', '3073', '2016-01-07 14:13:58', '41', '2016-01-07 14:13:58', '41', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1403', '1400', '60', '1452176038-7697-3', '3073', '2016-01-07 14:13:58', '41', '2016-01-07 14:13:58', '41', NULL, '2');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`) VALUES('1404', '1317', '2', 'for-page-1004', '17', '2016-01-07 14:24:12', '41', '2016-01-07 14:24:12', '41', '2016-01-07 14:24:12', '6');

DROP TABLE IF EXISTS `pages_access`;
CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1016', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1023', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1397', '2', '2016-01-07 14:12:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('37', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('38', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1026', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1053', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('32', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('34', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('35', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('36', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('50', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('51', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('52', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('53', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('54', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1006', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1010', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1012', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1013', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1014', '2', '2015-11-23 22:09:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1299', '2', '2015-12-06 10:45:22');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1054', '2', '2015-11-23 22:10:38');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1057', '1', '2015-11-27 11:07:52');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1357', '2', '2015-12-14 20:43:56');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1300', '2', '2015-12-06 10:45:22');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1301', '2', '2015-12-06 10:45:22');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1326', '2', '2015-12-10 21:07:18');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1304', '2', '2015-12-06 10:45:57');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1305', '2', '2015-12-06 10:45:57');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1307', '2', '2015-12-06 10:46:59');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1308', '2', '2015-12-06 10:46:59');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1309', '2', '2015-12-06 10:46:59');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1310', '2', '2015-12-06 10:49:52');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1312', '2', '2015-12-06 10:51:34');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1313', '2', '2015-12-06 10:51:34');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1314', '2', '2015-12-06 10:51:34');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1318', '2', '2015-12-09 16:32:10');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1319', '2', '2015-12-09 16:32:10');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1321', '2', '2015-12-09 18:15:19');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1322', '2', '2015-12-09 18:15:19');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1323', '2', '2015-12-09 18:15:19');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1329', '2', '2015-12-10 21:33:43');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1330', '2', '2015-12-10 21:33:43');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1331', '2', '2015-12-10 21:33:43');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1337', '1', '2015-12-13 17:53:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1339', '2', '2015-12-13 20:31:35');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1340', '2', '2015-12-13 20:31:35');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1341', '2', '2015-12-13 20:31:35');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1342', '1', '2015-12-14 17:24:10');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1356', '2', '2015-12-14 20:43:56');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1354', '2', '2015-12-14 20:43:17');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1352', '2', '2015-12-14 20:43:17');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1353', '2', '2015-12-14 20:43:17');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1358', '2', '2015-12-14 20:43:56');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1362', '2', '2015-12-14 22:34:50');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1363', '2', '2015-12-14 22:34:50');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1364', '2', '2015-12-14 22:34:50');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1365', '2', '2015-12-14 22:46:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1366', '2', '2015-12-14 22:46:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1367', '2', '2015-12-14 22:46:42');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1391', '1', '2016-01-07 13:43:03');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1395', '2', '2016-01-07 13:43:03');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1373', '1', '2015-12-14 23:51:44');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1394', '2', '2016-01-07 13:43:03');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1393', '2', '2016-01-07 13:43:03');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1377', '2', '2015-12-14 23:56:20');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1378', '2', '2015-12-14 23:56:20');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1379', '2', '2015-12-14 23:56:20');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('27', '1', '2015-12-15 01:31:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1380', '1', '2015-12-15 01:35:05');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1381', '1', '2015-12-15 01:53:40');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1382', '1', '2015-12-15 01:54:35');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1383', '1', '2015-12-15 01:55:18');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1384', '1', '2015-12-15 01:56:30');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1385', '1', '2015-12-15 03:07:50');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1398', '2', '2016-01-07 14:12:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1399', '2', '2016-01-07 14:12:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1401', '2', '2016-01-07 14:13:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1402', '2', '2016-01-07 14:13:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1403', '2', '2016-01-07 14:13:58');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1002', '2', '2016-01-07 14:24:06');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1004', '2', '2016-01-07 14:24:12');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1001', '2', '2016-01-07 14:24:15');

DROP TABLE IF EXISTS `pages_parents`;
CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('2', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('7', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1002', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1002', '1001');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1004', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1004', '1001');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1005', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '22');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1019', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1020', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1022', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1031', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1031', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1031', '1032');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1032', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1032', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1041', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1041', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1042', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1042', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1043', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1043', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1044', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1044', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1046', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1046', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1256', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1256', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1286', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1286', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1288', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1288', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1290', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1290', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1292', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1292', '1020');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1297', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1297', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1297', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1298', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1298', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1298', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1298', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1302', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1302', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1302', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1302', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1306', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1306', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1306', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1306', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1311', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1311', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1311', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1311', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1317', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1317', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1317', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1320', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1320', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1320', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1320', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1328', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1328', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1328', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1328', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1338', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1338', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1338', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1338', '1317');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1342', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1351', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1351', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1351', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1351', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1355', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1355', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1355', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1355', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1360', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1360', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1360', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1360', '1317');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1361', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1361', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1361', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1361', '1297');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1373', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1373', '1342');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1376', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1376', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1376', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1376', '1317');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1392', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1392', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1392', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1392', '1317');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1396', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1396', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1396', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1396', '1317');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1400', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1400', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1400', '1041');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1400', '1317');

DROP TABLE IF EXISTS `pages_sortfields`;
CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `session_login_throttle`;
CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `cache_time` mediumint(9) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('2', 'admin', '2', '8', '0', '{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1447883262}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('3', 'user', '3', '8', '0', '{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1,\"modified\":1450136212}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('4', 'role', '4', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('5', 'permission', '5', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('1', 'home', '1', '0', '0', '{\"useRoles\":1,\"noParents\":1,\"slashUrls\":1,\"modified\":1450130729,\"roles\":[37,1026,1053,1054]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('29', 'basic-page', '83', '0', '0', '{\"slashUrls\":1,\"label\":\"Basic Page\",\"modified\":1452176543}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('26', 'search', '80', '0', '0', '{\"noChildren\":1,\"noParents\":1,\"allowPageNum\":1,\"slashUrls\":1,\"modified\":1447883262}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('34', 'sitemap', '88', '0', '0', '{\"noChildren\":1,\"noParents\":1,\"redirectLogin\":23,\"slashUrls\":1,\"modified\":1447883262}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('43', 'language', '97', '8', '0', '{\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Language\",\"pageLabelField\":\"name\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noChangeTemplate\":1,\"noUnpublish\":1,\"nameContentTab\":1,\"modified\":1447889829}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('44', 'hersteller', '98', '0', '2419200', '{\"useRoles\":1,\"editRoles\":[1053],\"addRoles\":[1053],\"createRoles\":[1053],\"noInherit\":1,\"sortfield\":1,\"childTemplates\":[49],\"parentTemplates\":[47],\"slashUrls\":1,\"tags\":\"Freifunk\",\"modified\":1450028847,\"roles\":[37,1026,1053,1054]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('45', 'list_firmware', '99', '0', '0', '{\"slashUrls\":1,\"tags\":\"Lists\",\"modified\":1447970118}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('46', 'list_hersteller', '100', '0', '0', '{\"sortfield\":\"name\",\"noParents\":1,\"childTemplates\":[44],\"slashUrls\":1,\"tags\":\"Lists\",\"modified\":1447973623}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('47', 'list_router', '101', '0', '0', '{\"useRoles\":1,\"addRoles\":[1053],\"noInherit\":1,\"sortfield\":\"name\",\"noParents\":1,\"childTemplates\":[44],\"slashUrls\":1,\"cacheExpire\":-1,\"tags\":\"Lists\",\"modified\":1450137568,\"roles\":[37,1026,1053,1054]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('48', 'node', '102', '0', '0', '{\"noChildren\":1,\"parentTemplates\":[62],\"slashUrls\":1,\"useCacheForUsers\":1,\"tags\":\"Freifunk\",\"modified\":1450175568}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('49', 'router', '103', '0', '0', '{\"useRoles\":1,\"editRoles\":[1026,1053],\"addRoles\":[1053],\"createRoles\":[1053],\"noInherit\":1,\"childTemplates\":[53],\"parentTemplates\":[44],\"slashUrls\":1,\"cacheExpire\":2,\"tags\":\"Freifunk\",\"modified\":1450141707,\"roles\":[37,1026,1053,1054]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('50', 'features', '104', '0', '2419200', '{\"useRoles\":1,\"editRoles\":[1026,1053],\"createRoles\":[1026,1053],\"noChildren\":1,\"parentTemplates\":[51],\"slashUrls\":1,\"cacheExpire\":2,\"tags\":\"Freifunk\",\"modified\":1448316554,\"roles\":[37,1026,1053]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('51', 'list_features', '105', '0', '2419200', '{\"noParents\":-1,\"childTemplates\":[50],\"parentTemplates\":[1],\"slashUrls\":1,\"tags\":\"Lists\",\"modified\":1447973448}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('52', 'post', '106', '0', '86400', '{\"useRoles\":1,\"editRoles\":[1026,1053],\"createRoles\":[1026,1053],\"noChildren\":1,\"parentTemplates\":[54],\"slashUrls\":1,\"cacheExpire\":2,\"label\":\"Blog Post\",\"modified\":1448316430,\"roles\":[37,1026,1053]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('53', 'router_firmware', '107', '0', '86400', '{\"noChildren\":1,\"parentTemplates\":[49],\"slashUrls\":1,\"cacheExpire\":2,\"tags\":\"Freifunk\",\"modified\":1447973213}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('54', 'list_blog', '108', '0', '3600', '{\"useRoles\":1,\"addRoles\":[1026,1053],\"sortfield\":\"-116\",\"noParents\":1,\"childTemplates\":[52],\"slashUrls\":1,\"tags\":\"Lists\",\"modified\":1449782930,\"roles\":[37,1026,1053,1054]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('55', 'site-setting', '109', '0', '0', '{\"noChildren\":1,\"noParents\":-1,\"slashUrls\":1,\"pageLabelField\":\"fa-gears title\",\"label\":\"Site-Setting\",\"modified\":1448010485,\"label1023\":\"Seiten Einstellung\"}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('56', 'registration', '110', '0', '0', '{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"modified\":1450117435}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('57', 'edit_page', '111', '0', '0', '{\"slashUrls\":1,\"modified\":1448637583}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('58', 'repeater_alias_repeater', '112', '8', '0', '{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1448925337}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('59', 'repeater_Block', '113', '8', '0', '{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1449397752}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('60', 'repeater_on_page_blocks', '114', '8', '0', '{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1449399922}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('61', 'list_nodes', '115', '0', '0', '{\"noParents\":-1,\"urlSegments\":1,\"slashUrls\":1,\"tags\":\"Lists\",\"modified\":1450148238}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('62', 'node_operator', '116', '0', '0', '{\"sortfield\":\"name\",\"childTemplates\":[48],\"parentTemplates\":[61],\"slashUrls\":1,\"tags\":\"Freifunk\",\"modified\":1450144806}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('64', '404', '118', '0', '0', '{\"slashUrls\":1,\"modified\":1450143040}');

DROP TABLE IF EXISTS `textformatter_video_embed`;
CREATE TABLE `textformatter_video_embed` (
  `video_id` varchar(128) NOT NULL,
  `embed_code` varchar(1024) NOT NULL DEFAULT '',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `textformatter_video_embed` (`video_id`, `embed_code`, `created`) VALUES('7X_SXrJGupo', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/7X_SXrJGupo?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>', '2015-12-10 21:29:04');

UPDATE pages SET created_users_id=41, modified_users_id=41, created=NOW(), modified=NOW();

# --- /WireDatabaseBackup {"numTables":72,"numCreateTables":79,"numInserts":1270,"numSeconds":0}